import type { NextConfig } from 'next';

const nextConfig: NextConfig = {
  // typescript: { ignoreBuildErrors: true }, // Removed to reveal TypeScript errors
  // eslint: { ignoreDuringBuilds: true },   // Removed to reveal ESLint errors
  images: {
    remotePatterns: [
      {
        protocol: 'https',
        hostname: 'placehold.co',
        port: '',
        pathname: '/**',
      },
    ],
  },
};

export default nextConfig;
