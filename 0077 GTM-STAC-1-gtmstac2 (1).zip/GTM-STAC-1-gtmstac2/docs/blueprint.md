# **App Name**: SalesAI Navigator

## Core Features:

- Salesforce Integration: Connect and authenticate Salesforce accounts to enable data fetching.
- Integrated Search Bar: Implement a unified search bar that accepts prospect or company names.
- AI-Powered External Search: Use Gemini AI to search for publicly available information on the prospect or company and generate a summary.
- AI-Driven Insights & Recommendations: Based on available salesforce data, and, optionally, Gong/ZoomInfo, Gemini AI will recommend the next steps for a given prospect. This should operate as a tool that reviews and summarizes relevant details, with an understanding of possible next actions.
- Consolidated View: Display the aggregated information, AI insights, and next steps in a clear and organized format.

## Style Guidelines:

- Primary color: A muted blue (#6699CC) to convey trust and stability, which are important in a sales context. Avoid highly saturated blues.
- Background color: Light gray (#F0F0F0), provides a neutral backdrop. 
- Accent color: Soft orange (#D98880) for call-to-action buttons and important highlights.
- Use a clean, sans-serif font to ensure readability and a modern feel.
- Use consistent and professional icons to represent different data points and actions.
- Prioritize a clean and intuitive layout that allows sales teams to quickly find and understand information.