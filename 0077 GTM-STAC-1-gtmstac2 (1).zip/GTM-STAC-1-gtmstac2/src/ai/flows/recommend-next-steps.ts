
'use server';
/**
 * @fileOverview This flow analyzes Salesforce data and optionally Gong/ZoomInfo transcripts to recommend next steps for a prospect.
 *
 * - recommendNextSteps - A function that handles the recommendation process.
 * - RecommendNextStepsInput - The input type for the recommendNextSteps function.
 * - RecommendNextStepsOutput - The return type for the recommendNextSteps function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const RecommendNextStepsInputSchema = z.object({
  salesforceData: z
    .string()
    .describe('Salesforce data for the prospect in JSON format.'),
  gongZoomInfoTranscripts: z
    .string()
    .optional()
    .describe('Optional Gong/ZoomInfo transcripts or notes for the prospect.'),
});
export type RecommendNextStepsInput = z.infer<typeof RecommendNextStepsInputSchema>;

const RecommendNextStepsOutputSchema = z.object({
  nextSteps: z
    .string()
    .describe('Recommended next steps for the sales representative.'),
  reasoning: z
    .string()
    .describe('The AI reasoning behind the recommended next steps.'),
});
export type RecommendNextStepsOutput = z.infer<typeof RecommendNextStepsOutputSchema>;

export async function recommendNextSteps(input: RecommendNextStepsInput): Promise<RecommendNextStepsOutput> {
  return recommendNextStepsFlow(input);
}

const prompt = ai.definePrompt({
  name: 'recommendNextStepsPrompt',
  input: {schema: RecommendNextStepsInputSchema},
  output: {schema: RecommendNextStepsOutputSchema},
  prompt: `You are an AI sales assistant that analyzes sales data and recommends the next best steps for a sales representative.

  Analyze the following Salesforce data:
  {{salesforceData}}

  {% if gongZoomInfoTranscripts %}
  Consider the following Gong/ZoomInfo transcripts or notes:
  {{gongZoomInfoTranscripts}}
  {% endif %}

  Based on this information, recommend the next steps for the sales representative and explain your reasoning.

  Ensure that the nextSteps is in imperative tense. For example, "Schedule a follow-up call with the prospect."
  `,
});

const recommendNextStepsFlow = ai.defineFlow(
  {
    name: 'recommendNextStepsFlow',
    inputSchema: RecommendNextStepsInputSchema,
    outputSchema: RecommendNextStepsOutputSchema,
  },
  async input => {
    try {
      const result = await prompt(input);
      if (!result.output) {
        console.error(
          'recommendNextStepsFlow: AI prompt did not return a valid output structure.',
          result
        );
        // Return a default/error structure conforming to RecommendNextStepsOutputSchema
        return {
          nextSteps: 'Could not recommend next steps at this time. Please try again later.',
          reasoning: 'AI analysis for reasoning is currently unavailable.',
        };
      }
      return result.output;
    } catch (error) {
      console.error(
        'Error executing recommendNextStepsFlow prompt:',
        error
      );
      throw error; // Re-throw the error to be caught by the caller
    }
  }
);

