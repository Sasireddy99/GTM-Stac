
'use server';
/**
 * @fileOverview A prospect summary AI agent.
 *
 * - generateProspectSummary - A function that handles the prospect summary process.
 * - GenerateProspectSummaryInput - The input type for the generateProspectSummary function.
 * - GenerateProspectSummaryOutput - The return type for the generateProspectSummary function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const GenerateProspectSummaryInputSchema = z.object({
  prospectName: z.string().describe('The name of the prospect or company to search for.'),
});
export type GenerateProspectSummaryInput = z.infer<typeof GenerateProspectSummaryInputSchema>;

const GenerateProspectSummaryOutputSchema = z.object({
  summary: z.string().describe('A summary of the prospect or company, generated from publicly available information.'),
  insights: z.string().describe('Insights about the prospect or company and their potential needs.'),
});
export type GenerateProspectSummaryOutput = z.infer<typeof GenerateProspectSummaryOutputSchema>;

export async function generateProspectSummary(input: GenerateProspectSummaryInput): Promise<GenerateProspectSummaryOutput> {
  return generateProspectSummaryFlow(input);
}

const prompt = ai.definePrompt({
  name: 'generateProspectSummaryPrompt',
  input: {schema: GenerateProspectSummaryInputSchema},
  output: {schema: GenerateProspectSummaryOutputSchema},
  prompt: `You are a sales expert. Please provide a summary and insights for the following prospect or company based on publicly available information:\n\nProspect Name: {{{prospectName}}}`,
});

const generateProspectSummaryFlow = ai.defineFlow(
  {
    name: 'generateProspectSummaryFlow',
    inputSchema: GenerateProspectSummaryInputSchema,
    outputSchema: GenerateProspectSummaryOutputSchema,
  },
  async input => {
    try {
      const result = await prompt(input);
      if (!result.output) {
        console.error(
          'generateProspectSummaryFlow: AI prompt did not return a valid output structure.',
          result
        );
        // Return a default/error structure conforming to GenerateProspectSummaryOutputSchema
        return {
          summary: 'Could not generate summary at this time. Please try again later.',
          insights: 'Could not generate insights at this time. Please try again later.',
        };
      }
      return result.output;
    } catch (e) {
      console.error(
        'Error executing generateProspectSummaryFlow prompt:', e
      );
      throw e; // Re-throw the error to be caught by the caller
    }
  }
);

