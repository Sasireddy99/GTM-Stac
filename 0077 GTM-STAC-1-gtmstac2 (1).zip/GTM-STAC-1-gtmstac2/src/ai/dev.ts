import { config } from 'dotenv';
config();

import '@/ai/flows/generate-prospect-summary.ts';
import '@/ai/flows/recommend-next-steps.ts';