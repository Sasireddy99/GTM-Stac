
'use server';

import { db } from '@/lib/firebase';
import type { SalesforceRecord, OpportunityData } from '@/types';
import { collection, writeBatch, doc } from 'firebase/firestore';

const SALESFORCE_DATA_SUBCOLLECTION = 'salesforceData';
const ACCOUNTS_COLLECTION = 'accounts';
const OPPORTUNITIES_COLLECTION = 'opportunities';

export async function syncSalesforceDataAction(userId: string) {
  console.log(`[SalesforceAction] Attempting to sync LIVE data for user: ${userId}`);
  const appUrlFromEnv = process.env.NEXT_PUBLIC_APP_URL;
  console.log(`[SalesforceAction] Read NEXT_PUBLIC_APP_URL from environment: '${appUrlFromEnv}'`);

  if (!userId) {
    console.error('[SalesforceAction] No userId provided. Cannot sync data.');
    return { success: false, message: 'User ID is missing. Cannot sync data.', count: 0 };
  }

  if (!appUrlFromEnv) {
    console.error('[SalesforceAction] NEXT_PUBLIC_APP_URL is not set. Cannot make API call. Please check server environment variables.');
    return {
      success: false,
      message: 'Application URL is not configured for sync service. Please check server environment variables.',
      count: 0,
    };
  }

  const apiUrl = `${appUrlFromEnv}/api/salesforce/sync`;
  console.log(`[SalesforceAction] Fetching live data from: ${apiUrl}`);

  try {
    // In Next.js App Router, server actions run on the server.
    // Cookies need to be handled if the target API route relies on them for auth.
    // The API route /api/salesforce/sync relies on sf_access_token and sf_instance_url cookies.
    // For fetch in server actions, cookies are NOT automatically forwarded unless explicitly handled
    // or if the Next.js version/configuration implicitly does so for same-origin.
    // For now, we are assuming that the /api/salesforce/sync might work if the cookies are correctly
    // passed or if it's adapted to not require them for this specific call (e.g. using a service account).
    // This is a common point of failure if cookies are essential for the API route.
    // If it needs cookies, you might need to import `cookies` from `next/headers` and pass them.
    const response = await fetch(apiUrl, {
      method: 'GET',
      // headers: {
      //   Cookie: request.headers.get('cookie') || '', // Example if forwarding manually
      // },
    });

    console.log(`[SalesforceAction] API response status: ${response.status}`);

    if (!response.ok) {
      let errorBodyText = 'Could not retrieve error details from API response.';
      try {
        errorBodyText = await response.text(); // Try to get raw text first
        const errorData = JSON.parse(errorBodyText); // Then try to parse as JSON
        console.error(`[SalesforceAction] API request failed with status ${response.status}. Error data:`, errorData);
        let message = `Error syncing data: API request to ${apiUrl} failed (status ${response.status}).`;
        if (errorData && errorData.error) {
          message = `Error syncing data: ${errorData.error}`;
        } else if (response.status === 401) {
          message = 'Salesforce authorization is missing or invalid for the sync service. Please reconnect Salesforce and try again.';
        } else if (errorData) {
           message = `Error syncing data: API returned status ${response.status}. ${errorBodyText}`;
        }
        return { success: false, message, count: 0 };
      } catch (parseError) {
        console.error(`[SalesforceAction] API request failed with status ${response.status}. Failed to parse error response. Raw response: ${errorBodyText}`, parseError);
        return { success: false, message: `Error syncing data: API request to ${apiUrl} failed (status ${response.status}). Response was not valid JSON.`, count: 0 };
      }
    }

    const data = await response.json();

    if (!data.success) {
      console.error('[SalesforceAction] API reported an error:', data.message || data.error);
      return { success: false, message: data.message || data.error || 'API reported an unspecified error during sync.', count: 0 };
    }

    const accounts: SalesforceRecord[] = data.accounts || [];
    const opportunities: OpportunityData[] = data.opportunities || [];

    console.log(`[SalesforceAction] Received ${accounts.length} accounts and ${opportunities.length} opportunities from API for user ${userId}.`);

    if (accounts.length === 0 && opportunities.length === 0) {
      if (data.message && (data.message.includes("No data found") || data.message.includes("Successfully fetched 0 accounts and 0 opportunities"))) {
         console.warn('[SalesforceAction] Live data from API is empty as reported by API. Nothing to sync.');
         return { success: true, message: data.message , count: 0 };
      }
      console.warn('[SalesforceAction] Live data from API is empty. Nothing to sync.');
      return { success: true, message: 'No new live data found from Salesforce to sync.', count: 0 };
    }

    const batch = writeBatch(db);

    const userAccountsCollectionPath = `users/${userId}/${SALESFORCE_DATA_SUBCOLLECTION}/${ACCOUNTS_COLLECTION}`;
    accounts.forEach((record: SalesforceRecord) => {
      if (!record.id) {
        console.warn('[SalesforceAction] Skipping live account record due to missing ID:', record);
        return;
      }
      const recordRef = doc(db, userAccountsCollectionPath, record.id);
      batch.set(recordRef, record);
    });

    const userOpportunitiesCollectionPath = `users/${userId}/${SALESFORCE_DATA_SUBCOLLECTION}/${OPPORTUNITIES_COLLECTION}`;
    opportunities.forEach((opp: OpportunityData) => {
      if (!opp.id) {
        console.warn('[SalesforceAction] Skipping live opportunity record due to missing ID:', opp);
        return;
      }
      const oppRef = doc(db, userOpportunitiesCollectionPath, opp.id);
      batch.set(oppRef, opp);
    });

    if (accounts.length > 0 || opportunities.length > 0) {
      console.log(`[SalesforceAction] Committing batch of live data to Firestore for user ${userId}...`);
      await batch.commit();
      console.log(`[SalesforceAction] Live data batch committed successfully for user ${userId}.`);
    }

    return {
      success: true,
      message: `Successfully synced ${accounts.length} live accounts and ${opportunities.length} live opportunities from Salesforce.`,
      count: accounts.length + opportunities.length,
    };

  } catch (error: any) {
    console.error(`[SalesforceAction] Error fetching or processing live Salesforce data for user ${userId}:`, error);
    const fullError = error instanceof Error ? { message: error.message, stack: error.stack, name: error.name, cause: (error as any).cause } : { error: String(error) };
    console.error('[SalesforceAction] Full error details:', JSON.stringify(fullError, null, 2));
    
    let userMessage = 'An unexpected error occurred while syncing live Salesforce data.';
    if (error.message && error.message.toLowerCase().includes('fetch failed')) {
        // This specific message is key for diagnosing connection issues to the sync service
        userMessage = `Failed to connect to the sync service at ${apiUrl}. Please verify your application's URL configuration in the deployment environment and network connectivity.`;
    } else if (error.name === 'AbortError') {
        userMessage = 'The sync operation was aborted. Please try again.';
    }

    return {
      success: false,
      message: userMessage,
      count: 0,
    };
  }
}

    