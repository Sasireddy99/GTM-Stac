
import { NextResponse, type NextRequest } from 'next/server';
import { db } from '@/lib/firebase'; // Not used for writing here, action does that
// collection, writeBatch, doc are not used here
import axios from 'axios';
import { cookies } from 'next/headers';
import type { SalesforceRecord, OpportunityData } from '@/types'; // For type hints

export async function GET(request: NextRequest) {
  const cookieStore = await cookies();
  const accessToken = cookieStore.get('sf_access_token')?.value;
  const instanceUrl = cookieStore.get('sf_instance_url')?.value;

  console.log(`[API /api/salesforce/sync] GET request received. AccessToken present: ${!!accessToken}, InstanceURL present: ${!!instanceUrl}`);

  if (!accessToken || !instanceUrl) {
    console.warn('[API /api/salesforce/sync] Not authenticated with Salesforce. Missing access token or instance URL.');
    return NextResponse.json(
      { success: false, error: 'Not authenticated with Salesforce. Please connect and authorize first.' },
      { status: 401 }
    );
  }

  try {
    console.log('[API /api/salesforce/sync] Fetching Accounts from Salesforce...');
    const accountsQuery = "SELECT Id, Name, Industry, AnnualRevenue, NumberOfEmployees, Website FROM Account LIMIT 100";
    const accountsRes = await axios.get(
      `${instanceUrl}/services/data/v59.0/query?q=${encodeURIComponent(accountsQuery)}`,
      { headers: { Authorization: `Bearer ${accessToken}` } }
    );
    const rawAccounts = accountsRes.data.records || [];
    console.log(`[API /api/salesforce/sync] Fetched ${rawAccounts.length} raw accounts from Salesforce.`);

    const accounts: SalesforceRecord[] = rawAccounts.map((record: any) => ({
      id: record.Id,
      name: record.Name,
      industry: record.Industry,
      annualRevenue: record.AnnualRevenue,
      employeeCount: record.NumberOfEmployees,
      website: record.Website,
    }));

    console.log('[API /api/salesforce/sync] Fetching Opportunities from Salesforce...');
    const oppsQuery = "SELECT Id, Name, StageName, Amount, CloseDate, AccountId, Probability FROM Opportunity LIMIT 100";
    const oppsRes = await axios.get(
      `${instanceUrl}/services/data/v59.0/query?q=${encodeURIComponent(oppsQuery)}`,
      { headers: { Authorization: `Bearer ${accessToken}` } }
    );
    const rawOpportunities = oppsRes.data.records || [];
    console.log(`[API /api/salesforce/sync] Fetched ${rawOpportunities.length} raw opportunities from Salesforce.`);
    
    const opportunities: OpportunityData[] = rawOpportunities.map((opp: any) => ({
      id: opp.Id,
      name: opp.Name,
      stage: opp.StageName,
      amount: opp.Amount,
      closeDate: opp.CloseDate, 
      accountId: opp.AccountId,
      accountName: '', // This would need another query or join to get Account Name
      owner: 'Live Salesforce Data', 
      probability: typeof opp.Probability === 'number' ? opp.Probability / 100 : undefined,
    }));

    console.log(`[API /api/salesforce/sync] Successfully fetched data. Returning ${accounts.length} accounts and ${opportunities.length} opportunities.`);
    return NextResponse.json({
      success: true,
      accounts: accounts,
      opportunities: opportunities,
      message: `Successfully fetched ${accounts.length} accounts and ${opportunities.length} opportunities from Salesforce.`
    });

  } catch (error: any) {
    console.error('[API /api/salesforce/sync] Error fetching data from Salesforce during API call:', error.isAxiosError ? error.toJSON() : error);
    let errorMessage = 'Failed to fetch data from Salesforce. Please check your connection and try again.';
    let errorStatus = 500; // Default to 500 for unexpected errors

    if (error.isAxiosError && error.response) {
        // Handle Axios-specific errors (e.g., from Salesforce API)
        console.error('[API /api/salesforce/sync] Salesforce API Error Details:', error.response.data);
        const sfErrorData = error.response.data?.[0]; // Salesforce errors often come in an array
        if (sfErrorData?.errorCode === 'INVALID_SESSION_ID' || error.response.status === 401) {
            errorMessage = 'Salesforce session is invalid or expired. Please reconnect Salesforce and try again.';
            errorStatus = 401;
        } else if (sfErrorData?.message) {
            errorMessage = `Salesforce API Error: ${sfErrorData.message}`;
            errorStatus = error.response.status || 500;
        } else {
            errorMessage = `Salesforce API request failed with status ${error.response.status}. Check server logs for details.`;
            errorStatus = error.response.status || 500;
        }
    } else if (error.message) {
        // Handle generic errors (e.g., network issues before request, or non-Axios errors)
        errorMessage = `An unexpected error occurred while trying to sync with Salesforce: ${error.message}`;
    } else {
        // Fallback for truly unexpected errors without a message property
        errorMessage = 'An unknown error occurred during Salesforce synchronization.';
    }
    
    return NextResponse.json(
      { success: false, error: errorMessage, details: error.isAxiosError ? error.response?.data : String(error) },
      { status: errorStatus }
    );
  }
}
