// src/app/api/salesforce/status/route.ts
import { NextResponse } from 'next/server';
import { cookies } from 'next/headers';

// console.log('[API /api/salesforce/status] Module loaded - V2 DIAGNOSTIC'); // Reduced verbosity

export async function GET() {
  // console.log('[API /api/salesforce/status] GET request received - V2 DIAGNOSTIC'); // Reduced verbosity
  try {
    // console.log('[API /api/salesforce/status] Attempting to await cookies() - V2 DIAGNOSTIC'); // Reduced verbosity
    const cookieStore = await cookies(); // Ensure cookies() is awaited
    // console.log('[API /api/salesforce/status] cookies() awaited successfully - V2 DIAGNOSTIC'); // Reduced verbosity
    const accessToken = cookieStore.get('sf_access_token')?.value;

    if (accessToken) {
      // console.log('[API /api/salesforce/status] Access token found. User is connected.');
      return NextResponse.json({ connected: true }, { status: 200 });
    }
    // console.log('[API /api/salesforce/status] No access token found. User is not connected.');
    return NextResponse.json({ connected: false }, { status: 200 });
  } catch (error) {
    console.error('[API /api/salesforce/status] Error in GET handler:', error); // Kept essential error logging
    return NextResponse.json(
      { connected: false, error: 'Failed to read connection status.' },
      { status: 500 }
    );
  }
}
