
// src/app/api/salesforce/callback/route.ts
import { NextResponse, type NextRequest } from 'next/server';
import axios from 'axios';
import { db } from '@/lib/firebase'; // Firestore instance
import { doc, setDoc } from 'firebase/firestore'; // Firestore functions

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams;
  const code = searchParams.get('code');
  const state = searchParams.get('state'); // Firebase UserID passed from the client
  const error = searchParams.get('error');
  const errorDescription = searchParams.get('error_description');

  const nodeEnv = process.env.NODE_ENV;
  const envAppUrl = process.env.NEXT_PUBLIC_APP_URL;
  const reqOrigin = request.nextUrl.origin;

  console.log(`[API /api/salesforce/callback] GET request received. NODE_ENV: ${nodeEnv}`);
  console.log(`[API /api/salesforce/callback] env NEXT_PUBLIC_APP_URL: '${envAppUrl}'`);
  console.log(`[API /api/salesforce/callback] request.nextUrl.origin: '${reqOrigin}'`);
  console.log(`[API /api/salesforce/callback] Search Params from Salesforce: ${searchParams.toString()}`);
  console.log(`[API /api/salesforce/callback] Received state (Firebase UserID): ${state}`);


  let appBaseUrl: string;

  if (nodeEnv === 'development') {
    if (envAppUrl && !envAppUrl.includes('//0.0.0.0') && envAppUrl.startsWith('http')) {
      appBaseUrl = envAppUrl;
    } else {
      console.warn(`[API /api/salesforce/callback] Development: NEXT_PUBLIC_APP_URL ('${envAppUrl}') is invalid or not set. Defaulting to http://localhost:9002.`);
      appBaseUrl = 'http://localhost:9002';
    }
  } else {
    if (envAppUrl && !envAppUrl.includes('//0.0.0.0') && envAppUrl.startsWith('http')) {
      appBaseUrl = envAppUrl;
    } else {
      console.warn(`[API /api/salesforce/callback] Production: NEXT_PUBLIC_APP_URL ('${envAppUrl}') is invalid or not set. Falling back to request.nextUrl.origin ('${reqOrigin}').`);
      appBaseUrl = reqOrigin; 
      if (!appBaseUrl || appBaseUrl.includes('//0.0.0.0') || !appBaseUrl.startsWith('http')) {
         console.error(`[API /api/salesforce/callback] CRITICAL FALLBACK in Production: appBaseUrl derived from request origin is still '0.0.0.0' or invalid ('${appBaseUrl}'). The redirect WILL LIKELY FAIL.`);
      }
    }
  }
  
  console.log(`[API /api/salesforce/callback] Determined appBaseUrl for redirect: ${appBaseUrl}`);

  const targetPath = '/integrations/salesforce';
  let finalRedirectUrl: URL;

  try {
    if (!appBaseUrl || (!appBaseUrl.startsWith('http://') && !appBaseUrl.startsWith('https://'))) {
      console.error(`[API /api/salesforce/callback] Invalid appBaseUrl before new URL(): '${appBaseUrl}'`);
      throw new Error(`Invalid appBaseUrl for redirect: ${appBaseUrl}`);
    }
    finalRedirectUrl = new URL(targetPath, appBaseUrl);

    if (error) {
      console.error(`[API /api/salesforce/callback] Salesforce OAuth Error: ${error} - ${errorDescription}`);
      finalRedirectUrl.searchParams.set('error', error);
      finalRedirectUrl.searchParams.set('error_description', errorDescription || 'Salesforce authorization failed.');
    } else if (code) {
      console.log(`[API /api/salesforce/callback] Salesforce authorization code received (first few chars): ${code.substring(0, 10)}...`);
      
      const tokenEndpoint = process.env.SALESFORCE_TOKEN_URL;
      const clientId = process.env.NEXT_PUBLIC_SALESFORCE_CLIENT_ID;
      const clientSecret = process.env.SALESFORCE_CLIENT_SECRET;
      const redirectUriForTokenExchange = process.env.NEXT_PUBLIC_SALESFORCE_REDIRECT_URI;

      if (!tokenEndpoint || !clientId || !clientSecret || !redirectUriForTokenExchange) {
        console.error("[API /api/salesforce/callback] Missing Salesforce OAuth environment variables for token exchange.");
        finalRedirectUrl.searchParams.set('error', 'config_error');
        finalRedirectUrl.searchParams.set('error_description', 'Salesforce token exchange configuration is incomplete on the server.');
      } else {
        try {
          console.log("[API /api/salesforce/callback] Attempting token exchange with Salesforce.");
          const tokenRes = await axios.post(
            tokenEndpoint,
            new URLSearchParams({
              grant_type: 'authorization_code',
              code,
              client_id: clientId,
              client_secret: clientSecret,
              redirect_uri: redirectUriForTokenExchange, 
            }),
            { headers: { 'Content-Type': 'application/x-www-form-urlencoded' } }
          );

          const { access_token, refresh_token, instance_url, id_token } = tokenRes.data; // id_token might contain user info
          console.log("[API /api/salesforce/callback] Token exchange successful.");

          // Store tokens in Firestore associated with the Firebase user (identified by 'state')
          if (state && access_token && instance_url) { // 'state' here is the Firebase User ID
            const userSalesforceCredentialsRef = doc(db, "users", state, "salesforceCredentials", "credentialsDoc");
            await setDoc(userSalesforceCredentialsRef, {
              accessToken: access_token,
              refreshToken: refresh_token, // Store refresh token if available
              instanceUrl: instance_url,
              salesforceUserId: tokenRes.data.id, // Salesforce User ID from token response
              issuedAt: tokenRes.data.issued_at, // Timestamp
              updatedAt: new Date().toISOString(),
            }, { merge: true });
            console.log(`[API /api/salesforce/callback] Salesforce tokens stored in Firestore for user ${state}.`);
          } else {
            console.warn(`[API /api/salesforce/callback] Could not store tokens in Firestore: missing state (Firebase UserID), access_token, or instance_url.`);
          }
          
          finalRedirectUrl.searchParams.set('status', 'callback_received');
          finalRedirectUrl.searchParams.set('code_received', 'true'); 
          finalRedirectUrl.searchParams.set('sf_connected', 'true'); 

          const response = NextResponse.redirect(finalRedirectUrl.toString());
          
          // Also set tokens in HTTP-only cookies (current mechanism for /api/salesforce/sync)
          // This part can be phased out if /api/salesforce/sync is updated to use Firestore-stored tokens
          const cookieOptions = { 
            httpOnly: true, 
            secure: process.env.NODE_ENV === 'production',
            sameSite: 'lax' as const, 
            path: '/' 
          };
          response.cookies.set('sf_access_token', access_token, cookieOptions);
          if (refresh_token) {
              response.cookies.set('sf_refresh_token', refresh_token, cookieOptions);
          }
          response.cookies.set('sf_instance_url', instance_url, cookieOptions);
          
          console.log(`[API /api/salesforce/callback] Tokens also stored in cookies. Redirecting to: ${finalRedirectUrl.toString()}`);
          return response;

        } catch (tokenError: any) {
          console.error('[API /api/salesforce/callback] Token exchange failed:', tokenError.response?.data || tokenError.message || tokenError);
          finalRedirectUrl.searchParams.set('error', 'token_exchange_failed');
          finalRedirectUrl.searchParams.set('error_description', tokenError.response?.data?.error_description || 'Failed to exchange authorization code for access token.');
        }
      }
    } else {
      console.warn('[API /api/salesforce/callback] No code or error received from Salesforce.');
      finalRedirectUrl.searchParams.set('status', 'callback_incomplete');
    }

  } catch (e: any) {
    console.error(`[API /api/salesforce/callback] ERROR constructing finalRedirectUrl or in handler. Base: '${appBaseUrl}', Path: '${targetPath}'. Error: ${e.message}`);
    let safeFallbackBase = 'http://localhost:9002'; // Default for safety
    if (nodeEnv === 'production') {
        if (envAppUrl && envAppUrl.startsWith('http')) {
            safeFallbackBase = envAppUrl;
        } else if (reqOrigin && reqOrigin.startsWith('http')) {
            safeFallbackBase = reqOrigin;
        } else {
            console.error('[API /api/salesforce/callback] CRITICAL: Cannot determine safe fallback origin in production for error redirect.');
            // Return a minimal redirect to the integrations page, it will show default state
            const errorRedirect = new URL('/integrations/salesforce', 'https://your-production-app-url.com'); // Replace with actual static prod URL if needed
            errorRedirect.searchParams.set('error', 'internal_redirect_error_critical');
            return NextResponse.redirect(errorRedirect);
        }
    }
    const safeFallbackUrl = new URL('/integrations/salesforce', safeFallbackBase); 
    safeFallbackUrl.searchParams.set('error', 'internal_redirect_error');
    safeFallbackUrl.searchParams.set('error_description', `Could not construct redirect URL. Original error: ${e.message}`);
    console.log(`[API /api/salesforce/callback] Using error fallback redirect: ${safeFallbackUrl.toString()}`);
    return NextResponse.redirect(safeFallbackUrl.toString());
  }
  
  console.log(`[API /api/salesforce/callback] Attempting final redirect (no token exchange or error): ${finalRedirectUrl.toString()}`);
  return NextResponse.redirect(finalRedirectUrl.toString());
}
