// src/app/accounts/page.tsx
'use client';

import type { SalesforceRecord } from '@/types';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import Link from 'next/link';
import { useState, useEffect } from 'react';
import { useAuth } from '@/context/AuthContext';
import { db } from '@/lib/firebase';
import { collection, query, where, getDocs } from 'firebase/firestore';
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { AlertCircle } from 'lucide-react';

export default function AccountsPage() {
  const { user } = useAuth();
  const [accounts, setAccounts] = useState<SalesforceRecord[]>([]);
  // const [isLoading, setIsLoading] = useState(true);
  // const [error, setError] = useState<string | null>(null);

  // useEffect(() => {
  //   const fetchUserAccounts = async () => {
  //     if (!user) {
  //       // setIsLoading(false);
  //       setAccounts([]); 
  //       return;
  //     }
  //     // setIsLoading(true);
  //     // setError(null);
  //     try {
  //       const accountsPath = `users/${user.uid}/salesforceData/accounts`;
  //       const accountsCollectionRef = collection(db, accountsPath);
  //       const querySnapshot = await getDocs(accountsCollectionRef);

  //       if (!querySnapshot.empty) {
  //         const fetchedAccounts = (querySnapshot.docs as any[]).map(doc => ({ ...doc.data() as SalesforceRecord, id: doc.id }));
  //         setAccounts(fetchedAccounts);
  //       } else {
  //         setAccounts([]);
  //       }
  //     } catch (err: any) {
  //       console.error("Error fetching user accounts:", err);
  //       // setError("Failed to fetch accounts. Please ensure you are connected to the internet and try again.");
  //       setAccounts([]);
  //     } finally {
  //       // setIsLoading(false);
  //     }
  //   };

  //   fetchUserAccounts();
  // }, [user]);


  const formatCurrency = (amount?: number) => {
    if (amount === undefined || amount === null) return 'N/A';
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', minimumFractionDigits: 0, maximumFractionDigits: 0 }).format(amount);
  };
  
  if (!user) {
    return (
      <div className="p-6"> {/* Changed from container mx-auto p-6 */}
        <Card>
          <CardHeader>
            <CardTitle className="text-2xl font-semibold">Accounts</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">Please log in to view your accounts.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  // if (isLoading) {
  //   return <div className="p-6"><p>Loading accounts...</p></div>; // Changed from container mx-auto p-6
  // }

  // if (error) {
  //   return (
  //       <div className="p-6"> {/* Changed from container mx-auto p-6 */}
  //           <Alert variant="destructive">
  //               <AlertCircle className="h-4 w-4" />
  //               <AlertTitle>Error Fetching Accounts</AlertTitle>
  //               <AlertDescription>{error}</AlertDescription>
  //           </Alert>
  //       </div>
  //   );
  // }
  
  return (
    <div className="p-6"> {/* Changed from container mx-auto p-6 */}
      <Card className="w-full">
        <CardHeader>
          <CardTitle className="text-2xl font-semibold">Accounts</CardTitle>
        </CardHeader>
        <CardContent>
          {accounts.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Account Name</TableHead>
                  <TableHead>Industry</TableHead>
                  <TableHead>Employee Count</TableHead>
                  <TableHead>Annual Revenue</TableHead>
                  <TableHead>Website</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {accounts.map((account) => (
                  <TableRow key={account.id}>
                    <TableCell className="font-medium">{account.name}</TableCell>
                    <TableCell>{account.industry || 'N/A'}</TableCell>
                    <TableCell>{account.employeeCount?.toLocaleString() || 'N/A'}</TableCell>
                    <TableCell>{formatCurrency(account.annualRevenue)}</TableCell>
                    <TableCell>
                      {account.website ? (
                        <Link href={account.website.startsWith('http') ? account.website : `https://${account.website}`} target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">
                          {account.website}
                        </Link>
                      ) : (
                        'N/A'
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <p className="text-muted-foreground">No accounts found. Sync Salesforce data from the Integrations page.</p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
