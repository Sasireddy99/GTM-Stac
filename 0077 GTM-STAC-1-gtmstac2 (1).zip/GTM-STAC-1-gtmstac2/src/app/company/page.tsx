// src/app/company/page.tsx
'use client';

import { LandingHeader } from '@/components/landing/LandingHeader';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import Image from 'next/image';
import Link from 'next/link';
import { Building, Users, Target, Briefcase, Mail, Linkedin, Twitter, Facebook, type LucideIcon } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';

interface TeamMemberCardProps {
  name: string;
  title: string;
  imageUrl: string;
  imageHint: string;
  bio?: string;
}

const TeamMemberCard: React.FC<TeamMemberCardProps> = ({ name, title, imageUrl, imageHint, bio }) => (
  <Card className="text-center shadow-lg hover:shadow-xl transition-shadow duration-300">
    <CardContent className="p-6">
      <Avatar className="h-24 w-24 mx-auto mb-4 ring-2 ring-primary ring-offset-2 ring-offset-background">
        <AvatarImage src={imageUrl} alt={name} data-ai-hint={imageHint} />
        <AvatarFallback>{name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
      </Avatar>
      <h3 className="text-xl font-semibold text-foreground mb-1">{name}</h3>
      <p className="text-sm text-primary font-medium mb-2">{title}</p>
      {bio && <p className="text-xs text-muted-foreground">{bio}</p>}
    </CardContent>
  </Card>
);

const teamMembers = [
  { name: "Alex Johnson", title: "Founder & CEO", imageUrl: "https://placehold.co/100x100.png", imageHint:"ceo person", bio: "Visionary leader driving innovation in sales technology." },
  { name: "Maria Garcia", title: "Chief Technology Officer", imageUrl: "https://placehold.co/100x100.png", imageHint:"cto person", bio: "Expert architect behind our cutting-edge AI platform." },
  { name: "Sam Lee", title: "VP of Sales", imageUrl: "https://placehold.co/100x100.png", imageHint:"sales leader", bio: "Strategic sales executive passionate about customer success." },
  { name: "Priya Sharma", title: "Head of Product", imageUrl: "https://placehold.co/100x100.png", imageHint:"product manager", bio: "Dedicated to building intuitive and impactful solutions for sales teams." },
];

export default function CompanyPage() {
  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground">
      <LandingHeader />
      <main className="flex-grow container mx-auto px-4 py-12">
        <section className="text-center mb-16 pt-12">
          <div className="inline-block p-4 bg-primary/10 rounded-full mb-6">
            <Building className="h-16 w-16 text-primary" />
          </div>
          <h1 className="text-4xl md:text-5xl font-bold text-primary mb-4">About SalesAI Navigator</h1>
          <p className="text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto">
            We are passionate about revolutionizing the sales industry through the power of artificial intelligence. Learn more about our mission, vision, and the team dedicated to your success.
          </p>
        </section>

        <section className="mb-20 grid md:grid-cols-2 gap-12 items-center">
            <div>
                <Image src="https://placehold.co/600x400.png" alt="Our Mission" width={600} height={400} className="rounded-lg shadow-xl" data-ai-hint="team collaboration"/>
            </div>
            <div>
                <h2 className="text-3xl font-semibold text-foreground mb-4 flex items-center">
                    <Target className="h-8 w-8 text-primary mr-3" /> Our Mission
                </h2>
                <p className="text-md text-muted-foreground leading-relaxed mb-3">
                    To empower sales professionals worldwide with intelligent tools that automate mundane tasks, provide actionable insights, and enable personalized engagement, ultimately helping them close more deals and build stronger customer relationships.
                </p>
                <p className="text-md text-muted-foreground leading-relaxed">
                    We believe that AI should augment human capabilities, not replace them. SalesAI Navigator is designed to be an intuitive co-pilot, enhancing the skills and expertise of sales teams to achieve peak performance.
                </p>
            </div>
        </section>
        
        <section className="mb-20 py-12 bg-secondary/50 rounded-lg">
          <h2 className="text-3xl font-semibold text-center mb-12">Meet Our Leadership Team</h2>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8 px-6">
            {teamMembers.map((member) => (
              <TeamMemberCard
                key={member.name}
                name={member.name}
                title={member.title}
                imageUrl={member.imageUrl}
                imageHint={member.imageHint}
                bio={member.bio}
              />
            ))}
          </div>
        </section>

        <section className="mb-20 text-center">
          <h2 className="text-3xl font-semibold text-foreground mb-6">Join Our Team</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-8">
            We&apos;re always looking for talented and passionate individuals to join us on our mission. If you&apos;re excited about the future of sales and AI, check out our open positions.
          </p>
          <Button size="lg" variant="default" className="text-lg py-3 px-8 shadow-lg" asChild>
            <Link href="#"> {/* Placeholder for careers page */}
              View Careers <Briefcase className="ml-2 h-5 w-5" />
            </Link>
          </Button>
        </section>

        <section className="py-16 bg-card rounded-lg shadow-xl">
            <h2 className="text-3xl font-semibold text-center text-primary mb-10">Contact Us</h2>
            <div className="max-w-3xl mx-auto grid md:grid-cols-2 gap-8 items-start">
                <div className="space-y-4">
                    <h3 className="text-xl font-semibold text-foreground">Get in Touch</h3>
                    <p className="text-muted-foreground">We&apos;d love to hear from you! Whether you have a question about features, trials, pricing, or anything else, our team is ready to answer all your questions.</p>
                    <div className="flex items-center space-x-3">
                        <Mail className="h-5 w-5 text-primary" />
                        <a href="mailto:info@salesainavigator.com" className="hover:underline text-muted-foreground">info@salesainavigator.com</a>
                    </div>
                     <div className="flex items-center space-x-3">
                        <Phone className="h-5 w-5 text-primary" />
                        <span className="text-muted-foreground">+1 (555) 123-4567</span>
                    </div>
                    <div className="flex space-x-3 pt-2">
                        <Button variant="outline" size="icon" asChild><Link href="#"><Linkedin className="h-5 w-5"/></Link></Button>
                        <Button variant="outline" size="icon" asChild><Link href="#"><Twitter className="h-5 w-5"/></Link></Button>
                        <Button variant="outline" size="icon" asChild><Link href="#"><Facebook className="h-5 w-5"/></Link></Button>
                    </div>
                </div>
                 <form className="space-y-4">
                    <div>
                        <label htmlFor="name" className="block text-sm font-medium text-foreground mb-1">Full Name</label>
                        <input type="text" name="name" id="name" className="w-full px-3 py-2 border border-border rounded-md focus:ring-primary focus:border-primary bg-background" placeholder="John Doe"/>
                    </div>
                    <div>
                        <label htmlFor="email-contact" className="block text-sm font-medium text-foreground mb-1">Email Address</label>
                        <input type="email" name="email" id="email-contact" className="w-full px-3 py-2 border border-border rounded-md focus:ring-primary focus:border-primary bg-background" placeholder="you@example.com"/>
                    </div>
                    <div>
                        <label htmlFor="message" className="block text-sm font-medium text-foreground mb-1">Message</label>
                        <textarea name="message" id="message" rows={4} className="w-full px-3 py-2 border border-border rounded-md focus:ring-primary focus:border-primary bg-background" placeholder="Your message..."></textarea>
                    </div>
                    <Button type="submit" className="w-full">Send Message</Button>
                </form>
            </div>
        </section>

      </main>
      <footer className="py-8 border-t border-border/20 bg-background">
        <div className="container mx-auto text-center text-muted-foreground text-sm">
          &copy; {new Date().getFullYear()} SalesAI Navigator. All rights reserved.
        </div>
      </footer>
    </div>
  );
}
