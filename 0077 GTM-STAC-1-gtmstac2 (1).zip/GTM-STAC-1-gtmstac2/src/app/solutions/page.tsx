// src/app/solutions/page.tsx
'use client';

import { LandingHeader } from '@/components/landing/LandingHeader';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import Image from 'next/image';
import Link from 'next/link';
import { CheckCircle, Zap, BarChart, Brain, Users, Briefcase, Settings, UserCheck, Headphones, BarChartBig, Megaphone, Target, type LucideIcon } from 'lucide-react';

interface BenefitCardProps {
  icon: LucideIcon;
  title: string;
  description: string;
}

const BenefitCard: React.FC<BenefitCardProps> = ({ icon: Icon, title, description }) => (
  <Card className="bg-card shadow-lg hover:shadow-xl transition-shadow duration-300 text-center">
    <CardHeader className="items-center">
      <div className="p-4 bg-primary/10 rounded-full mb-4 inline-block">
        <Icon className="h-10 w-10 text-primary" />
      </div>
      <CardTitle className="text-2xl font-semibold text-foreground">{title}</CardTitle>
    </CardHeader>
    <CardContent>
      <p className="text-muted-foreground text-md">{description}</p>
    </CardContent>
  </Card>
);

interface SolutionDetailCardProps {
    icon: LucideIcon;
    title: string;
    description: string;
    imageUrl: string;
    imageHint: string;
    benefits: string[];
}

const SolutionDetailCard: React.FC<SolutionDetailCardProps> = ({ icon: Icon, title, description, imageUrl, imageHint, benefits }) => (
    <Card className="overflow-hidden shadow-xl">
        <div className="relative w-full h-56">
             <Image src={imageUrl} alt={title} layout="fill" objectFit="cover" data-ai-hint={imageHint} />
        </div>
        <CardHeader>
            <div className="flex items-center mb-2">
                <Icon className="h-8 w-8 text-primary mr-3" />
                <CardTitle className="text-2xl">{title}</CardTitle>
            </div>
            <CardDescription>{description}</CardDescription>
        </CardHeader>
        <CardContent>
            <h4 className="font-semibold mb-2 text-md">Key Benefits:</h4>
            <ul className="space-y-1.5">
                {benefits.map((benefit, index) => (
                    <li key={index} className="flex items-start text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                        <span>{benefit}</span>
                    </li>
                ))}
            </ul>
            <Button variant="link" className="px-0 mt-4 text-primary" asChild>
                <Link href="/contact">Learn More <Target className="ml-2 h-4 w-4" /></Link>
            </Button>
        </CardContent>
    </Card>
);

const coreBenefits = [
  {
    icon: Zap,
    title: "Increase Efficiency",
    description: "Spend less time on manual tasks and more time selling. Our AI handles repetitive work so your team can focus on building relationships and closing deals.",
  },
  {
    icon: BarChart,
    title: "Boost Conversion Rates",
    description: "Identify the most promising leads and engage them with personalized communication at the right time, significantly improving your chances of success.",
  },
  {
    icon: Brain,
    title: "Gain Deeper Insights",
    description: "Understand your customers and market dynamics like never before. Make data-driven decisions to optimize your sales strategy and outperform the competition.",
  },
];

const roleSolutions = [
    {
        icon: Headphones,
        title: "Solution for Sales Representatives",
        description: "Empower your reps with AI tools to automate research, personalize outreach, and close deals faster.",
        imageUrl: "https://placehold.co/600x400.png",
        imageHint: "sales representative",
        benefits: ["Automated prospect research", "AI-generated email drafts", "Real-time sales recommendations", "Reduced administrative tasks"]
    },
    {
        icon: BarChartBig,
        title: "Solution for Sales Leaders",
        description: "Gain comprehensive pipeline visibility, accurate forecasting, and actionable insights to drive team performance.",
        imageUrl: "https://placehold.co/600x400.png",
        imageHint: "manager dashboard",
        benefits: ["Accurate sales forecasting", "Team performance analytics", "Identification of coaching opportunities", "Strategic pipeline management"]
    },
    {
        icon: Megaphone,
        title: "Solution for Marketing Teams",
        description: "Align marketing efforts with sales intelligence for better lead quality, refined targeting, and impactful campaigns.",
        imageUrl: "https://placehold.co/600x400.png",
        imageHint: "marketing strategy",
        benefits: ["Improved lead scoring & qualification", "Data-driven content generation ideas", "Enhanced campaign targeting", "Better sales and marketing alignment"]
    }
];


export default function SolutionsPage() {
  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground">
      <LandingHeader />
      <main className="flex-grow container mx-auto px-4 py-12">
        <section className="text-center mb-16 pt-12">
          <h1 className="text-4xl md:text-5xl font-bold text-primary mb-4">Solutions Tailored for Your Success</h1>
          <p className="text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto">
            SalesAI Navigator offers a suite of AI-powered solutions designed to address your specific sales challenges and help you achieve your revenue goals.
          </p>
        </section>

        <section className="mb-20">
          <h2 className="text-3xl font-semibold text-center mb-12">Core Benefits of SalesAI Navigator</h2>
          <div className="grid md:grid-cols-3 gap-8">
            {coreBenefits.map((benefit) => (
              <BenefitCard
                key={benefit.title}
                icon={benefit.icon}
                title={benefit.title}
                description={benefit.description}
              />
            ))}
          </div>
        </section>
        
        <section className="mb-20 py-12 bg-secondary/50 rounded-lg">
          <h2 className="text-3xl font-semibold text-center mb-12 px-4">Empowering Every Role in Your Revenue Engine</h2>
           <div className="grid md:grid-cols-1 lg:grid-cols-3 gap-8 px-6">
            {roleSolutions.map((solution) => (
                <SolutionDetailCard 
                    key={solution.title}
                    icon={solution.icon}
                    title={solution.title}
                    description={solution.description}
                    imageUrl={solution.imageUrl}
                    imageHint={solution.imageHint}
                    benefits={solution.benefits}
                />
            ))}
          </div>
        </section>

        <section className="mb-16 text-center">
          <h2 className="text-3xl font-semibold mb-6">Explore Use Cases</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto mb-10">
            Discover how SalesAI Navigator can be applied to various sales scenarios to drive tangible results.
          </p>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              { title: "Improving Lead Qualification", description: "Use AI to score and prioritize leads, ensuring your team focuses on the most promising opportunities." },
              { title: "Streamlining Sales Outreach", description: "Automate personalized email sequences and follow-ups to engage prospects effectively." },
              { title: "Enhancing Sales Forecasting", description: "Leverage predictive analytics for more accurate revenue forecasts and resource planning." },
              { title: "Optimizing Sales Training", description: "Identify skill gaps and provide targeted coaching based on performance data and AI insights." },
              { title: "Personalizing Product Demos", description: "Tailor demonstrations to specific prospect needs highlighted by AI-driven research." },
              { title: "Reducing Sales Cycle Length", description: "Accelerate deals through the pipeline with intelligent recommendations and automation." },
            ].map(useCase => (
              <Card key={useCase.title} className="bg-card shadow-md p-6">
                <CardTitle className="text-xl text-primary mb-3">{useCase.title}</CardTitle>
                <CardContent className="p-0">
                  <p className="text-sm text-muted-foreground">{useCase.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>
        
        <section className="py-16 text-center bg-primary/10 rounded-lg">
          <h2 className="text-3xl font-bold text-primary mb-6">Ready to Implement these Solutions?</h2>
          <p className="text-lg text-muted-foreground max-w-xl mx-auto mb-8">
            Let SalesAI Navigator be the catalyst for your sales transformation.
          </p>
          <div className="space-x-4">
            <Button size="lg" className="text-lg py-3 px-8 shadow-lg" asChild>
              <Link href="/signup">Start Free Trial</Link>
            </Button>
            <Button variant="outline" size="lg" className="text-lg py-3 px-8 shadow-lg text-primary border-primary hover:bg-primary/10" asChild>
              <Link href="/contact">Request a Demo</Link>
            </Button>
          </div>
        </section>

      </main>
      <footer className="py-8 border-t border-border/20 bg-background">
        <div className="container mx-auto text-center text-muted-foreground text-sm">
          &copy; {new Date().getFullYear()} SalesAI Navigator. All rights reserved.
        </div>
      </footer>
    </div>
  );
}
