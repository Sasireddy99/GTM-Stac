// src/app/page.tsx
'use client';

import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { BarChart, Users, Briefcase, MessageSquare, Search as SearchIcon } from "lucide-react";
import { useRouter } from "next/navigation";
import { Input } from "@/components/ui/input";
import { useAuth } from '@/context/AuthContext';
import LandingPage from '@/components/landing/LandingPage';
import DashboardContent from '@/components/dashboard/DashboardContent';
import { Loader2 } from 'lucide-react';

export default function Page() {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen bg-background text-foreground">
        <Loader2 className="h-12 w-12 animate-spin text-primary mb-4" />
        <p className="text-lg text-muted-foreground">Loading SalesAI Navigator...</p>
      </div>
    );
  }

  if (!user) {
    return <LandingPage />;
  }

  // User is authenticated, show the dashboard content
  // The RootLayout will provide the AppSidebar, AppHeader, etc.
  return <DashboardContent />;
}
