// src/app/signup/page.tsx
'use client';

import { useState, type FormEvent } from 'react';
import { useRouter } from 'next/navigation';
import { signInWithPopup, GoogleAuthProvider, createUserWithEmailAndPassword, updateProfile } from 'firebase/auth';
import { auth, db } from '@/lib/firebase'; // Added db
import { doc, setDoc } from 'firebase/firestore'; // Added setDoc and doc
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { AlertCircle, UserPlus, Mail, Lock, User, Building } from 'lucide-react'; // Added Building icon
import Link from 'next/link';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';

export default function SignupPage() {
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isGoogleLoading, setIsGoogleLoading] = useState(false);
  const router = useRouter();

  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [companyName, setCompanyName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleEmailPasswordSignUp = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setIsLoading(true);
    setError(null);

    if (!firstName.trim() || !lastName.trim()) {
        setError("First name and last name are required.");
        setIsLoading(false);
        return;
    }
    if (!companyName.trim()) { // Mandatory company name check
        setError("Company name is required.");
        setIsLoading(false);
        return;
    }
    if (password.length < 6) {
      setError("Password should be at least 6 characters.");
      setIsLoading(false);
      return;
    }

    try {
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      const user = userCredential.user;
      const displayName = `${firstName.trim()} ${lastName.trim()}`;
      await updateProfile(user, {
        displayName: displayName,
      });

      // Store additional user info (including companyName) in Firestore
      if (user) {
        const userDocRef = doc(db, "users", user.uid);
        await setDoc(userDocRef, {
          uid: user.uid,
          email: user.email,
          displayName: displayName,
          companyName: companyName.trim(), // Store trimmed company name
          createdAt: new Date().toISOString(), // Optional: timestamp
        });
      }

      router.push('/'); // Redirect to dashboard or desired page after signup
    } catch (err: any) {
      console.error("Email/Password Sign-Up Error:", err);
      if (err.code === 'auth/email-already-in-use') {
        setError('This email address is already in use. Please try logging in or use a different email.');
      } else if (err.code === 'auth/weak-password') {
        setError('The password is too weak. Please choose a stronger password (at least 6 characters).');
      } else if (err.code === 'auth/invalid-email') {
        setError('The email address is not valid. Please enter a valid email.');
      }
      else {
        setError(err.message || 'Failed to sign up. Please try again.');
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleGoogleSignUp = async () => {
    setIsGoogleLoading(true);
    setError(null);
    const provider = new GoogleAuthProvider();
    try {
      const userCredential = await signInWithPopup(auth, provider);
      const user = userCredential.user;
      if (user) {
        const userDocRef = doc(db, "users", user.uid);
        await setDoc(userDocRef, {
          uid: user.uid,
          email: user.email,
          displayName: user.displayName,
          companyName: '', // Intentionally set to empty to trigger collection later
          createdAt: new Date().toISOString(),
        }, { merge: true }); 
      }
      router.push('/');
    } catch (err: any) {
      console.error("Google Sign-Up Error:", err);
      setError(err.message || 'Failed to sign up with Google. Please try again.');
    } finally {
      setIsGoogleLoading(false);
    }
  };

  return (
    <div className="flex items-center justify-center min-h-full py-12 px-4 sm:px-6 lg:px-8 bg-background">
      <Card className="w-full max-w-md shadow-xl">
        <CardHeader className="text-center">
          <CardTitle className="text-3xl font-bold tracking-tight text-foreground">
            Create an account
          </CardTitle>
          <CardDescription className="mt-2">
            Join SalesAI Navigator to boost your sales.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {error && (
             <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Signup Error</AlertTitle>
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          <form onSubmit={handleEmailPasswordSignUp} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1">
                <Label htmlFor="firstName">First Name</Label>
                <div className="relative">
                  <User className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    id="firstName"
                    type="text"
                    placeholder="John"
                    value={firstName}
                    onChange={(e) => setFirstName(e.target.value)}
                    required
                    className="pl-8"
                  />
                </div>
              </div>
              <div className="space-y-1">
                <Label htmlFor="lastName">Last Name</Label>
                 <div className="relative">
                  <User className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    id="lastName"
                    type="text"
                    placeholder="Doe"
                    value={lastName}
                    onChange={(e) => setLastName(e.target.value)}
                    required
                    className="pl-8"
                  />
                </div>
              </div>
            </div>

            <div className="space-y-1">
              <Label htmlFor="companyName">Company Name</Label>
              <div className="relative">
                <Building className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  id="companyName"
                  type="text"
                  placeholder="Acme Corp"
                  value={companyName}
                  onChange={(e) => setCompanyName(e.target.value)}
                  required 
                  className="pl-8"
                />
              </div>
            </div>

            <div className="space-y-1">
              <Label htmlFor="email-signup">Email address</Label>
              <div className="relative">
                <Mail className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  id="email-signup"
                  type="email"
                  placeholder="you@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="pl-8"
                />
              </div>
            </div>
            <div className="space-y-1">
              <Label htmlFor="password-signup">Password</Label>
              <div className="relative">
                <Lock className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  id="password-signup"
                  type="password"
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  className="pl-8"
                />
              </div>
            </div>
            <Button type="submit" disabled={isLoading || isGoogleLoading} className="w-full">
              {isLoading ? (
                <UserPlus className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <UserPlus className="mr-2 h-4 w-4" />
              )}
              {isLoading ? 'Creating account...' : 'Sign up with Email'}
            </Button>
          </form>

          <div className="relative my-6">
            <div className="absolute inset-0 flex items-center">
              <Separator />
            </div>
            <div className="relative flex justify-center text-xs uppercase">
              <span className="bg-background px-2 text-muted-foreground">
                Or continue with
              </span>
            </div>
          </div>

          <Button
            onClick={handleGoogleSignUp}
            disabled={isLoading || isGoogleLoading}
            className="w-full"
            variant="outline"
          >
            {isGoogleLoading ? (
              <UserPlus className="mr-2 h-4 w-4 animate-spin" />
            ) : (
               <svg className="mr-2 h-4 w-4" aria-hidden="true" focusable="false" data-prefix="fab" data-icon="google" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 488 512">
                <path fill="currentColor" d="M488 261.8C488 403.3 381.5 512 244 512 110.3 512 0 401.8 0 265.2S110.3 18.3 244 18.3c68.1 0 128.5 27.2 172.4 70.4l-67.2 67.2c-20.3-19.2-48.9-30.9-79.7-30.9-65.8 0-119.7 54.1-119.7 120.8s54 120.8 119.7 120.8c72.3 0 102.8-54.1 106.3-82.3H244v-86.h244z"></path>
              </svg>
            )}
            {isGoogleLoading ? 'Processing...' : 'Sign up with Google'}
          </Button>
        </CardContent>
        <CardFooter className="flex justify-center">
          <p className="text-sm text-muted-foreground">
            Already have an account?{' '}
            <Link href="/login" className="font-medium text-primary hover:underline">
              Sign in
            </Link>
          </p>
        </CardFooter>
      </Card>
    </div>
  );
}
