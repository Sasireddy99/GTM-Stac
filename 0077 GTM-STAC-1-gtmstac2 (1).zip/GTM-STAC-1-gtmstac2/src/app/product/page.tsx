// src/app/product/page.tsx
'use client';

import { LandingHeader } from '@/components/landing/LandingHeader';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import Image from 'next/image';
import Link from 'next/link';
import { ArrowRight, Brain, Zap, PieChart, Search, Headphones, BarChartBig, Megaphone, Settings, UserCheck, Cloud, Linkedin, Database, Briefcase, ShieldCheck, type LucideIcon } from 'lucide-react';

interface FeatureCardProps {
  icon: LucideIcon;
  title: string;
  description: string;
  imageUrl?: string;
  imageHint?: string;
}

const FeatureCard: React.FC<FeatureCardProps> = ({ icon: Icon, title, description, imageUrl, imageHint }) => (
  <Card className="bg-card shadow-lg hover:shadow-xl transition-shadow duration-300 flex flex-col overflow-hidden">
    {imageUrl && (
      <div className="relative w-full h-48">
        <Image src={imageUrl} alt={title} layout="fill" objectFit="cover" data-ai-hint={imageHint || "feature illustration"} />
      </div>
    )}
    <CardHeader>
      <div className="flex items-center text-primary mb-2">
        <Icon className="h-7 w-7 mr-3 flex-shrink-0" />
        <CardTitle className="text-xl font-semibold text-foreground">{title}</CardTitle>
      </div>
    </CardHeader>
    <CardContent className="flex-grow">
      <p className="text-muted-foreground text-sm">{description}</p>
    </CardContent>
  </Card>
);

const features = [
  {
    icon: Search,
    title: "AI-Powered Search & Discovery",
    description: "Uncover comprehensive prospect profiles by leveraging AI to search and synthesize data from Salesforce, LinkedIn, ZoomInfo, and the open web.",
    imageUrl: "https://placehold.co/600x400.png",
    imageHint: "data search",
  },
  {
    icon: Brain,
    title: "AI-Driven Insights",
    description: "Get actionable intelligence on prospects, companies, and market trends to tailor your approach and identify key opportunities.",
    imageUrl: "https://placehold.co/600x400.png",
    imageHint: "analytics graph",
  },
  {
    icon: Zap,
    title: "Workflow Automation",
    description: "Automate repetitive tasks like data entry, follow-up reminders, and initial email drafting, freeing up your team for strategic selling.",
    imageUrl: "https://placehold.co/600x400.png",
    imageHint: "automation gears",
  },
  {
    icon: PieChart,
    title: "Personalized Outreach at Scale",
    description: "Craft compelling, data-driven messages that resonate with each prospect's unique needs and pain points, improving engagement.",
    imageUrl: "https://placehold.co/600x400.png",
    imageHint: "communication connection",
  },
];

const platformCapabilities = [
  {
    icon: Headphones,
    title: "For Sales Representatives",
    description: "Automate research, craft personalized emails, get next-step recommendations, and stay on top of follow-ups effortlessly. Focus on building relationships and closing deals.",
    imageUrl: "https://placehold.co/600x400.png",
    imageHint: "salesperson success"
  },
  {
    icon: BarChartBig,
    title: "For Sales Leaders",
    description: "Gain pipeline visibility, forecast accurately, identify coaching opportunities, and optimize team performance with data-driven insights and comprehensive reporting.",
    imageUrl: "https://placehold.co/600x400.png",
    imageHint: "leadership strategy"
  },
  {
    icon: Megaphone,
    title: "For Marketing Teams",
    description: "Understand lead quality, refine targeting, generate compelling content ideas, and align messaging with sales efforts for a cohesive go-to-market strategy.",
    imageUrl: "https://placehold.co/600x400.png",
    imageHint: "marketing campaign"
  },
  {
    icon: Settings,
    title: "For Account Management",
    description: "Identify upsell/cross-sell opportunities, monitor account health, and personalize client communication for improved retention and growth.",
    imageUrl: "https://placehold.co/600x400.png",
    imageHint: "customer relationship"
  },
  {
    icon: UserCheck,
    title: "For Customer Success",
    description: "Proactively address customer needs, identify churn risks, and personalize support interactions for improved satisfaction and loyalty.",
    imageUrl: "https://placehold.co/600x400.png",
    imageHint: "customer support"
  },
];

const integrations = [
    { name: "Salesforce", icon: Cloud, color: "text-blue-500" },
    { name: "LinkedIn Sales Navigator", icon: Linkedin, color: "text-blue-700" },
    { name: "ZoomInfo", icon: Database, color: "text-red-500" },
    { name: "HubSpot", icon: Briefcase, color: "text-orange-500" },
    { name: "Outreach", icon: ShieldCheck, color: "text-purple-500" },
];


export default function ProductPage() {
  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground">
      <LandingHeader />
      <main className="flex-grow container mx-auto px-4 py-12">
        <section className="text-center mb-16 pt-12">
          <h1 className="text-4xl md:text-5xl font-bold text-primary mb-4">Our Product: SalesAI Navigator</h1>
          <p className="text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto">
            Empowering sales teams with cutting-edge AI to drive efficiency, gain deeper insights, and achieve remarkable results. SalesAI Navigator is your intelligent co-pilot for every step of the sales journey.
          </p>
        </section>

        <section className="mb-20">
          <h2 className="text-3xl font-semibold text-center mb-12">Core Features</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-2 gap-8">
            {features.map((feature) => (
              <FeatureCard
                key={feature.title}
                icon={feature.icon}
                title={feature.title}
                description={feature.description}
                imageUrl={feature.imageUrl}
                imageHint={feature.imageHint}
              />
            ))}
          </div>
        </section>

        <section className="mb-20 py-12 bg-secondary/50 rounded-lg">
          <h2 className="text-3xl font-semibold text-center mb-12">Platform Capabilities for Every Role</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 px-6">
            {platformCapabilities.map((capability) => (
              <FeatureCard
                key={capability.title}
                icon={capability.icon}
                title={capability.title}
                description={capability.description}
                imageUrl={capability.imageUrl}
                imageHint={capability.imageHint}
              />
            ))}
          </div>
        </section>
        
        <section className="mb-16 text-center">
            <h2 className="text-3xl font-semibold mb-10">Seamless Integrations</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto mb-12">
                SalesAI Navigator works with the tools you already use, bringing all your sales intelligence into one powerful platform.
            </p>
            <div className="flex flex-wrap justify-center items-center gap-x-10 gap-y-8">
            {integrations.map((integration) => (
                <div key={integration.name} className="flex flex-col items-center space-y-2 w-36">
                    <integration.icon className={`h-12 w-12 ${integration.color}`} />
                    <span className="text-sm font-medium text-foreground">{integration.name}</span>
                </div>
            ))}
            </div>
        </section>

        <section className="py-16 text-center bg-primary/10 rounded-lg">
          <h2 className="text-3xl font-bold text-primary mb-6">Ready to Transform Your Sales Process?</h2>
          <p className="text-lg text-muted-foreground max-w-xl mx-auto mb-8">
            Experience the power of AI-driven sales intelligence. Get started with SalesAI Navigator today.
          </p>
          <div className="space-x-4">
            <Button size="lg" className="text-lg py-3 px-8 shadow-lg" asChild>
              <Link href="/signup">Get Started Free</Link>
            </Button>
            <Button variant="outline" size="lg" className="text-lg py-3 px-8 shadow-lg text-primary border-primary hover:bg-primary/10" asChild>
              <Link href="/solutions">Explore Solutions</Link>
            </Button>
          </div>
        </section>

      </main>
      <footer className="py-8 border-t border-border/20 bg-background">
        <div className="container mx-auto text-center text-muted-foreground text-sm">
          &copy; {new Date().getFullYear()} SalesAI Navigator. All rights reserved.
        </div>
      </footer>
    </div>
  );
}
