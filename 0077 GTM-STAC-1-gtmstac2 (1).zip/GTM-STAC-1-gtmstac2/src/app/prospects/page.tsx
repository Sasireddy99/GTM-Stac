// src/app/prospects/page.tsx
'use client';

import type { SalesforceRecord } from '@/types';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { format } from 'date-fns';
import { useState, useEffect } from 'react';
import { useAuth } from '@/context/AuthContext';
import { db } from '@/lib/firebase';
import { collection, query, where, getDocs } from 'firebase/firestore';
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { AlertCircle } from 'lucide-react';

const getProspectStatusBadgeVariant = (status?: SalesforceRecord['status']): "default" | "secondary" | "destructive" | "outline" => {
  if (!status) return 'outline';
  switch (status) {
    case 'Customer':
      return 'default';
    case 'Lead':
      return 'outline';
    case 'Contacted':
    case 'Qualified':
    case 'Proposal Sent':
      return 'secondary';
    case 'Lost':
      return 'destructive';
    default:
      return 'outline';
  }
};

export default function ProspectsPage() {
  const { user } = useAuth();
  const [prospects, setProspects] = useState<SalesforceRecord[]>([]);
  // const [isLoading, setIsLoading] = useState(true);
  // const [error, setError] = useState<string | null>(null);

  // useEffect(() => {
  //   const fetchUserProspects = async () => {
  //     if (!user) {
  //       // setIsLoading(false);
  //       setProspects([]);
  //       return;
  //     }
  //     // setIsLoading(true);
  //     // setError(null);
  //     try {
  //       // Fetching from 'accounts' collection as per current data model for prospects/companies
  //       const prospectsPath = `users/${user.uid}/salesforceData/accounts`; 
  //       const prospectsCollectionRef = collection(db, prospectsPath);
  //       const querySnapshot = await getDocs(prospectsCollectionRef);

  //       if (!querySnapshot.empty) {
  //         const fetchedProspects = (querySnapshot.docs as any[]).map(doc => ({ ...doc.data() as SalesforceRecord, id: doc.id }));
  //         setProspects(fetchedProspects);
  //       } else {
  //         setProspects([]);
  //       }
  //     } catch (err: any) {
  //       console.error("Error fetching user prospects:", err);
  //       // setError("Failed to fetch prospects. Please ensure you are connected to the internet and try again.");
  //       setProspects([]);
  //     } finally {
  //       // setIsLoading(false);
  //     }
  //   };

  //   fetchUserProspects();
  // }, [user]);

  if (!user) { 
    return (
      <div className="p-6"> {/* Changed from container mx-auto p-6 */}
        <Card>
          <CardHeader>
            <CardTitle className="text-2xl font-semibold">Prospects</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">Please log in to view your prospects.</p>
          </CardContent>
        </Card>
      </div>
    );
  }
  
  // if (isLoading) {
  //   return <div className="p-6"><p>Loading prospects...</p></div>; // Changed from container mx-auto p-6
  // }

  // if (error) {
  //    return (
  //       <div className="p-6"> {/* Changed from container mx-auto p-6 */}
  //           <Alert variant="destructive">
  //               <AlertCircle className="h-4 w-4" />
  //               <AlertTitle>Error Fetching Prospects</AlertTitle>
  //               <AlertDescription>{error}</AlertDescription>
  //           </Alert>
  //       </div>
  //   );
  // }

  return (
    <div className="p-6"> {/* Changed from container mx-auto p-6 */}
      <Card className="w-full">
        <CardHeader>
          <CardTitle className="text-2xl font-semibold">Prospects</CardTitle>
        </CardHeader>
        <CardContent>
          {prospects.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Contact Person</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Industry</TableHead>
                  <TableHead className="text-right">Last Contacted</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {prospects.map((prospect) => (
                  <TableRow key={prospect.id}>
                    <TableCell className="font-medium">{prospect.name}</TableCell>
                    <TableCell>{prospect.contactPerson || 'N/A'}</TableCell>
                    <TableCell>{prospect.email || 'N/A'}</TableCell>
                    <TableCell>
                      {prospect.status ? (
                        <Badge variant={getProspectStatusBadgeVariant(prospect.status)}>
                          {prospect.status}
                        </Badge>
                      ) : (
                        'N/A'
                      )}
                    </TableCell>
                    <TableCell>{prospect.industry || 'N/A'}</TableCell>
                    <TableCell className="text-right">
                      {prospect.lastContacted
                        ? format(new Date(prospect.lastContacted), 'MMM d, yyyy')
                        : 'N/A'}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <p className="text-muted-foreground">No prospects found. Sync Salesforce data from the Integrations page.</p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
