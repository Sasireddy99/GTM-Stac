// src/app/search/page.tsx
'use client';

import { useEffect, useState, Suspense } from 'react';
import { useSearchParams, useRouter } from 'next/navigation';
import { useAuth } from '@/context/AuthContext';
import { generateProspectSummary } from '@/ai/flows/generate-prospect-summary';
import { recommendNextSteps } from '@/ai/flows/recommend-next-steps';
import { fetchSalesforceRecordByName } from '@/lib/salesforce';
import type { SalesforceRecord, ProspectSummary, NextSteps } from '@/types';

import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { AlertCircle, Info, ExternalLink, PlusCircle, Lightbulb, MessageSquare, CalendarDays, FileText, Users, Brain, Sparkles } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';

function SearchResultsContent() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const { user } = useAuth();

  const query = searchParams.get('q');

  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [salesforceRecord, setSalesforceRecord] = useState<SalesforceRecord | null>(null);
  const [prospectSummary, setProspectSummary] = useState<ProspectSummary | null>(null);
  const [nextSteps, setNextSteps] = useState<NextSteps | null>(null);

  useEffect(() => {
    if (query && user) {
      const performSearch = async () => {
        setIsLoading(true);
        setError(null);
        setSalesforceRecord(null);
        setProspectSummary(null);
        setNextSteps(null);

        try {
          const summaryPromise = generateProspectSummary({ prospectName: query });
          const sfRecordPromise = fetchSalesforceRecordByName(query, user.uid);

          const [summaryResult, sfRecordResult] = await Promise.all([summaryPromise, sfRecordPromise]);
          
          setProspectSummary(summaryResult);
          setSalesforceRecord(sfRecordResult);

          if (sfRecordResult) {
            const nextStepsResult = await recommendNextSteps({ salesforceData: JSON.stringify(sfRecordResult, null, 2) });
            setNextSteps(nextStepsResult);
          }
        } catch (e: any) {
          console.error("Search page error:", e);
          setError(e.message || "An unexpected error occurred during the search.");
        } finally {
          setIsLoading(false);
        }
      };
      performSearch();
    } else if (!query) {
      // Optionally redirect or show a message if no query
      // router.push('/'); // Or show an "Enter a search term" message
    }
  }, [query, user, router]);

  if (!query) {
    return (
      <div className="p-6 text-center">
        <Info className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
        <p className="text-lg text-muted-foreground">Please enter a search term on the dashboard.</p>
        <Button onClick={() => router.push('/')} className="mt-4">Back to Dashboard</Button>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="p-6 space-y-8">
        <div className="flex justify-between items-center">
          <Skeleton className="h-10 w-1/4" />
          <div className="flex space-x-2">
            <Skeleton className="h-10 w-36" />
            <Skeleton className="h-10 w-40" />
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Skeleton className="h-64 rounded-lg" />
          <Skeleton className="h-64 rounded-lg" />
          <Skeleton className="h-64 rounded-lg" />
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-6">
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Search Error</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      </div>
    );
  }

  if (!salesforceRecord && !prospectSummary) {
    return (
      <div className="p-6 text-center">
        <AlertCircle className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
        <p className="text-lg text-muted-foreground">No results found for &quot;{query}&quot;.</p>
        <Button onClick={() => router.push('/')} className="mt-4">Back to Dashboard</Button>
      </div>
    );
  }

  const contactName = salesforceRecord?.contactPerson || prospectSummary?.summary?.split(',')[0] || query; // Basic fallback
  const companyName = salesforceRecord?.name || query;

  return (
    <div className="p-6 space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <h1 className="text-3xl font-bold text-foreground">{companyName}</h1>
        <div className="flex space-x-2 flex-shrink-0">
          <Button variant="outline"><ExternalLink className="mr-2 h-4 w-4" />View in Salesforce</Button>
          <Button><PlusCircle className="mr-2 h-4 w-4" />Add to Opportunity</Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-start">
        {/* Column 1: Contact Information */}
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle>Contact Information</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 text-sm">
            {salesforceRecord ? (
              <>
                <InfoItem label="Full Name" value={salesforceRecord.contactPerson || 'N/A'} />
                <InfoItem label="Title" value={'N/A'} /> {/* Add Title if available in SF record */}
                <InfoItem label="Company" value={salesforceRecord.name} />
                <InfoItem label="Email" value={salesforceRecord.email || 'N/A'} />
                <InfoItem label="Phone" value={salesforceRecord.phone || 'N/A'} />
                <InfoItem label="Location" value={
                  salesforceRecord.address ? 
                  `${salesforceRecord.address.city || ''}${salesforceRecord.address.city && salesforceRecord.address.state ? ', ' : ''}${salesforceRecord.address.state || ''}` 
                  : 'N/A'
                } />
              </>
            ) : (
              <p className="text-muted-foreground">No Salesforce contact information available.</p>
            )}
          </CardContent>
        </Card>

        {/* Column 2: AI-Generated Insights */}
        <Card className="lg:col-span-1">
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle>AI-Generated Insights</CardTitle>
              <Badge variant="outline" className="text-xs bg-muted">
                <Sparkles className="h-3 w-3 mr-1 text-primary" /> Gemini AI
              </Badge>
            </div>
          </CardHeader>
          <CardContent className="space-y-4 text-sm">
            {prospectSummary ? (
              <>
                <div>
                  <h4 className="font-semibold text-foreground mb-1">Company Summary</h4>
                  <p className="text-muted-foreground">{prospectSummary.summary || 'No summary available.'}</p>
                </div>
                <div>
                  <h4 className="font-semibold text-foreground mb-1">Recent News</h4>
                  <ul className="list-disc list-inside text-muted-foreground space-y-1 pl-1">
                    <li>{contactName} was recently promoted to their current role (3 months ago)</li>
                    <li>{companyName} announced new growth initiatives (1 month ago)</li>
                    <li>Industry trends show increasing demand for solutions in the technology space (2 weeks ago)</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-semibold text-foreground mb-1">Potential Pain Points</h4>
                  <ul className="list-disc list-inside text-muted-foreground space-y-1 pl-1">
                    <li><AlertCircle className="inline h-4 w-4 mr-1 text-destructive/70" />Managing increasing workloads with limited resources</li>
                    <li><AlertCircle className="inline h-4 w-4 mr-1 text-destructive/70" />Maintaining competitive edge in a rapidly evolving market</li>
                    <li><AlertCircle className="inline h-4 w-4 mr-1 text-destructive/70" />Streamlining processes to improve operational efficiency</li>
                  </ul>
                </div>
              </>
            ) : (
              <p className="text-muted-foreground">No AI-generated insights available.</p>
            )}
          </CardContent>
        </Card>

        {/* Column 3: Sales Recommendations */}
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle>Sales Recommendations</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 text-sm">
            <div>
              <h4 className="font-semibold text-foreground mb-2">Key Contacts to Engage</h4>
              <div className="flex items-center space-x-2">
                <Avatar>
                  <AvatarFallback>{contactName?.substring(0,2).toUpperCase() || 'SC'}</AvatarFallback>
                </Avatar>
                <div>
                  <p className="font-medium text-foreground">{contactName || 'N/A'}</p>
                  <p className="text-xs text-muted-foreground">Decision Maker - Primary Contact</p>
                </div>
              </div>
            </div>
            <div>
              <h4 className="font-semibold text-foreground mb-2">Suggested Next Actions</h4>
              <div className="space-y-2">
                <ActionItem icon={Lightbulb} text={nextSteps?.nextSteps?.split('\n')[0] || "Highlight time-saving aspects of your solution"} bgColor="bg-green-500/10" />
                <ActionItem icon={CalendarDays} text={nextSteps?.nextSteps?.split('\n')[1] || "Schedule a personalized demo focused on ROI"} bgColor="bg-blue-500/10" />
                <ActionItem icon={FileText} text={nextSteps?.nextSteps?.split('\n')[2] || "Share relevant case studies from similar companies"} bgColor="bg-purple-500/10" />
              </div>
            </div>
            <div>
              <h4 className="font-semibold text-foreground mb-1">Conversation Intelligence</h4>
              <div className="p-3 bg-muted/50 rounded-md">
                <p className="text-xs text-muted-foreground mb-1">From last call (Apr 15, 2023)</p>
                <p className="text-foreground">
                  {nextSteps?.reasoning || '"In previous conversations, the prospect expressed interest in solutions that provide immediate value without extensive implementation periods."'}
                </p>
                <p className="text-primary mt-1 text-xs hover:underline cursor-pointer">Focus on our phased implementation methodology in the next conversation.</p>
              </div>
            </div>
            <Button className="w-full mt-2" variant="outline">
              <MessageSquare className="mr-2 h-4 w-4" />Generate Custom Outreach Email
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

const InfoItem: React.FC<{ label: string; value: string | number | undefined }> = ({ label, value }) => (
  <div>
    <p className="text-xs text-muted-foreground">{label}</p>
    <p className="text-foreground font-medium">{value || 'N/A'}</p>
  </div>
);

interface ActionItemProps {
  icon: React.ElementType;
  text: string;
  bgColor?: string;
}
const ActionItem: React.FC<ActionItemProps> = ({ icon: Icon, text, bgColor = "bg-secondary/30" }) => (
  <div className={`flex items-center p-2 rounded-md ${bgColor}`}>
    <Icon className="h-4 w-4 mr-2 text-primary" />
    <span className="text-foreground">{text}</span>
  </div>
);

export default function SearchPage() {
  return (
    <Suspense fallback={<div className="p-6">Loading search results...</div>}>
      <SearchResultsContent />
    </Suspense>
  );
}
