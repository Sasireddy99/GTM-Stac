
'use client';

import { useState, useEffect, Suspense } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Zap, RotateCw, AlertCircle, CheckCircle2, ExternalLink, ShieldCheck } from 'lucide-react';
import { syncSalesforceDataAction } from '@/actions/salesforceActions';
import { format } from 'date-fns';
import { useSearchParams } from 'next/navigation';
import { Skeleton } from '@/components/ui/skeleton';
import { useAuth } from '@/context/AuthContext'; // Import useAuth

function SalesforceIntegrationPageComponent() {
  const { user } = useAuth(); // Get authenticated user
  const [isConnecting, setIsConnecting] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [checkingStatus, setCheckingStatus] = useState(true);
  const [connectionStatus, setConnectionStatus] = useState<string>('disconnected'); // 'disconnected', 'pending_callback', 'authorized', 'syncing', 'sync_success', 'sync_error', 'callback_error', 'config_error'
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [lastSyncTime, setLastSyncTime] = useState<string | null>(null);
  const [recordsSynced, setRecordsSynced] = useState<number | null>(null);

  const searchParams = useSearchParams();

  useEffect(() => {
    console.log('[Salesforce Integration Page] Raw searchParams:', searchParams.toString());
    const errorParam = searchParams.get('error');
    const errorDescriptionParam = searchParams.get('error_description');
    const sfConnectedParam = searchParams.get('sf_connected'); // From our callback after token exchange
    const statusParam = searchParams.get('status'); // General status from callback

    console.log(`[Salesforce Integration Page] Parsed params: sf_connected='${sfConnectedParam}', error='${errorParam}', error_description='${errorDescriptionParam}', status='${statusParam}'`);

    if (errorParam) {
      setConnectionStatus('callback_error');
      setStatusMessage(`Salesforce OAuth Error: ${errorParam} - ${errorDescriptionParam || 'Authorization failed.'}`);
      setCheckingStatus(false);
      return;
    }

    if (sfConnectedParam === 'true' && statusParam === 'callback_received') {
      setConnectionStatus('authorized');
      setStatusMessage('Salesforce connected successfully. You can now sync data.');
      setCheckingStatus(false);
      // Optionally clear params from URL: window.history.replaceState({}, document.title, "/integrations/salesforce");
      return;
    }
    
    if (statusParam === 'callback_incomplete') {
        setConnectionStatus('disconnected');
        setStatusMessage('Salesforce authorization was not completed.');
        setCheckingStatus(false);
        return;
    }


    // If not coming from a successful callback, check backend status via API
    console.log('[Salesforce Integration Page] Checking connection status with /api/salesforce/status');
    fetch('/api/salesforce/status')
      .then(res => {
        if (!res.ok) {
          throw new Error(`API status check failed with status ${res.status}`);
        }
        return res.json();
      })
      .then(data => {
        if (data.connected) {
          setConnectionStatus('authorized');
          setStatusMessage('Salesforce connection active. Ready to sync.');
          console.log('[Salesforce Integration Page] Status API reports connected.');
        } else {
          setConnectionStatus('disconnected');
          console.log('[Salesforce Integration Page] Status API reports disconnected.');
        }
      })
      .catch((err) => {
        setConnectionStatus('disconnected');
        setStatusMessage('Could not verify Salesforce connection status from API.');
        console.error('[Salesforce Integration Page] Error fetching connection status:', err);
      })
      .finally(() => setCheckingStatus(false));
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [searchParams]);

  const handleConnectSalesforce = () => {
    if (!user) {
      setStatusMessage("Please log in to your SalesAI Navigator account first to connect Salesforce.");
      setConnectionStatus('config_error'); // Or a new state like 'user_not_logged_in'
      return;
    }

    setIsConnecting(true);
    setStatusMessage(null);
    setConnectionStatus('pending_callback');

    const loginUrl = process.env.NEXT_PUBLIC_SALESFORCE_LOGIN_URL;
    const clientId = process.env.NEXT_PUBLIC_SALESFORCE_CLIENT_ID;
    const redirectUri = process.env.NEXT_PUBLIC_SALESFORCE_REDIRECT_URI;

    console.log('[Salesforce Integration] Attempting to connect. Values from environment:');
    console.log(`[Salesforce Integration] Login URL from .env: '${loginUrl}'`);
    console.log(`[Salesforce Integration] Client ID from .env: '${clientId}'`);
    console.log(`[Salesforce Integration] Redirect URI from .env: '${redirectUri}'`);

    if (!loginUrl || !clientId || !redirectUri) {
      const missingVars = [];
      if (!loginUrl) missingVars.push('NEXT_PUBLIC_SALESFORCE_LOGIN_URL');
      if (!clientId) missingVars.push('NEXT_PUBLIC_SALESFORCE_CLIENT_ID');
      if (!redirectUri) missingVars.push('NEXT_PUBLIC_SALESFORCE_REDIRECT_URI');
      
      setStatusMessage(`Salesforce integration is not configured correctly. Missing environment variables: ${missingVars.join(', ')}. Check your .env file (for local development) or your deployment environment settings, and restart your server/deployment if changes were made.`);
      setConnectionStatus('config_error');
      setIsConnecting(false);
      return;
    }

    if (clientId === "YOUR_SALESFORCE_CLIENT_ID_HERE" || clientId.startsWith("YOUR_")) {
      setStatusMessage("Salesforce Client ID is still a placeholder. Please update the NEXT_PUBLIC_SALESFORCE_CLIENT_ID in your .env file (for local development) or your deployment environment settings with your actual Client ID, and then restart your development server or redeploy to connect.");
      setConnectionStatus('config_error');
      setIsConnecting(false);
      return;
    }

    const salesforceState = user.uid; // Use Firebase UID as state

    const params = new URLSearchParams({
      response_type: 'code',
      client_id: clientId,
      redirect_uri: redirectUri,
      scope: 'api refresh_token full',
      state: salesforceState, // Add state parameter
    });
    
    const authorizationUrl = `${loginUrl}/services/oauth2/authorize?${params.toString()}`;
    console.log('[Salesforce Integration] Constructed Authorization URL:', authorizationUrl);
    window.location.href = authorizationUrl;
  };

  const handleSyncData = async () => {
    if (!user) {
      setStatusMessage("User not logged in. Cannot sync data.");
      setConnectionStatus('config_error');
      return;
    }
    setIsSyncing(true);
    setConnectionStatus('syncing');
    setStatusMessage('Syncing Salesforce data to your user-specific store in Firestore...');
    try {
      // Pass the userId to the action
      const result = await syncSalesforceDataAction(user.uid);
      if (result.success) {
        setConnectionStatus('sync_success');
        setStatusMessage(result.message || `Successfully synced ${result.count} records from Salesforce.`);
        setLastSyncTime(format(new Date(), 'PPpp'));
        setRecordsSynced(result.count);
      } else {
        setConnectionStatus('sync_error');
        setStatusMessage(result.message || 'Sync failed. Check server logs for details.');
      }
    } catch (error: any) {
      setConnectionStatus('sync_error');
      setStatusMessage(error.message || 'An unexpected error occurred during sync.');
      console.error('[Salesforce Integration Page] Sync Data Error:', error);
    } finally {
      setIsSyncing(false);
    }
  };

  const getStatusDisplay = () => {
    if (connectionStatus === 'disconnected') return 'Not Connected';
    if (connectionStatus === 'pending_callback') return 'Awaiting Salesforce Authorization...';
    if (connectionStatus === 'callback_error') return 'Salesforce Authorization Failed';
    if (connectionStatus === 'config_error') return 'Configuration Error';
    if (connectionStatus === 'authorized') return 'Salesforce Connected';
    if (connectionStatus === 'syncing') return 'Syncing Data...';
    if (connectionStatus === 'sync_success') return `Data Synced (${recordsSynced ?? 0} records)`;
    if (connectionStatus === 'sync_error') return 'Sync Error';
    return 'Verifying...';
  };

  const showConnectButton = ['disconnected', 'callback_error', 'config_error', 'callback_incomplete'].includes(connectionStatus);
  const showSyncButton = ['authorized', 'sync_success', 'sync_error'].includes(connectionStatus) && !isSyncing;
  
  console.log('[Salesforce Integration Page] Current connectionStatus:', connectionStatus);
  console.log('[Salesforce Integration Page] Show Connect Button:', showConnectButton);
  console.log('[Salesforce Integration Page] Show Sync Button:', showSyncButton);

  if (checkingStatus) { 
    return <SalesforcePageSkeleton />;
  }

  return (
    <div className="p-6"> {/* Changed from container mx-auto p-6 */}
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl font-semibold flex items-center">
            <svg
              role="img"
              viewBox="0 0 24 24"
              xmlns="http://www.w3.org/2000/svg"
              className="h-7 w-7 mr-2 text-blue-500"
              fill="currentColor"
            >
              <title>Salesforce</title>
              <path d="M11.999 0C5.638 0 .515 5.09.515 11.406c0 5.308 3.555 9.827 8.412 11.045.416.08.56-.177.56-.396v-1.43c-3.291.708-3.994-1.58-3.994-1.58-.38-1.016-1.026-1.256-1.026-1.256-.83-.56.048-.56.048-.56.88.072 1.372.888 1.372.888.806 1.368 2.099.984 2.603.744.07-.592.302-1.008.538-1.224-1.968-.216-4.054-1.008-4.054-4.428 0-.984.336-1.776.89-2.388-.085-.216-.398-1.152.071-2.388 0 0 .756-.24 2.448.888.707-.204 1.469-.288 2.23-.288.762 0 1.523.084 2.23.288 1.69-1.128 2.447-.888 2.447-.888.47 1.236.157 2.172.072 2.388.553.612.89 1.404.89 2.388 0 3.432-2.085 4.212-4.052 4.416.302.264.576.792.576 1.584v2.304c0 .216.144.48.562.396C20.003 21.25 23.485 16.71 23.485 11.405 23.485 5.091 18.362 0 11.999 0Z"></path>
            </svg>
            Salesforce Integration
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-muted-foreground">
            Connect your Salesforce account to enable live data synchronization.
            This integration will store your Salesforce data securely in your user-specific area in our database.
            Currently, the "Sync Salesforce Data" button uses a predefined mock dataset for demonstration.
          </p>
          <div className="flex items-center p-4 border rounded-lg bg-secondary/30">
            {connectionStatus === 'authorized' || connectionStatus === 'sync_success' ? (
              <ShieldCheck className="h-8 w-8 text-green-500 mr-4" />
            ) : connectionStatus === 'callback_error' || connectionStatus === 'sync_error' || connectionStatus === 'config_error' ? (
              <AlertCircle className="h-8 w-8 text-destructive mr-4" />
            ) : (
              <Zap className="h-8 w-8 text-muted-foreground mr-4" />
            )}
            <div>
              <p className="font-semibold text-foreground">
                Status: {getStatusDisplay()}
              </p>
              {(connectionStatus === 'disconnected' && !statusMessage && !user) && (
                  <p className="text-sm text-muted-foreground">Please log in to SalesAI Navigator to connect Salesforce.</p>
              )}
              {(connectionStatus === 'disconnected' && !statusMessage && user) && (
                <p className="text-sm text-muted-foreground">Click "Connect & Authorize" to begin.</p>
              )}
              {lastSyncTime && (connectionStatus === 'sync_success' || connectionStatus === 'authorized') && (
                <p className="text-xs text-muted-foreground">Last data sync: {lastSyncTime}</p>
              )}
            </div>
          </div>
          {statusMessage && (
            <div className={`p-3 border rounded-md flex items-center 
              ${connectionStatus === 'sync_success' || connectionStatus === 'authorized' ? 'bg-green-500/10 text-green-700' : ''}
              ${connectionStatus === 'callback_error' || connectionStatus === 'sync_error' || connectionStatus === 'config_error' ? 'bg-destructive/10 text-destructive' : ''}
              ${connectionStatus === 'pending_callback' || connectionStatus === 'syncing' ? 'bg-blue-500/10 text-blue-700' : ''}
            `}>
              {connectionStatus === 'sync_success' || connectionStatus === 'authorized' ? <CheckCircle2 className="h-5 w-5 mr-2" /> : 
               connectionStatus === 'callback_error' || connectionStatus === 'sync_error' || connectionStatus === 'config_error' ? <AlertCircle className="h-5 w-5 mr-2" /> :
               connectionStatus === 'pending_callback' || connectionStatus === 'syncing' ? <RotateCw className="h-5 w-5 mr-2 animate-spin" /> :
               <Zap className="h-5 w-5 mr-2" />
              }
              <p className="text-sm">{statusMessage}</p>
            </div>
          )}

          <div className="space-x-2">
            {showConnectButton && (
              <Button onClick={handleConnectSalesforce} disabled={isConnecting || checkingStatus || !user}>
                {isConnecting ? (
                  <RotateCw className="mr-2 h-4 w-4 animate-spin" />
                ) : (
                  <ExternalLink className="mr-2 h-4 w-4" />
                )}
                {isConnecting ? 'Redirecting...' : 'Connect & Authorize with Salesforce'}
              </Button>
            )}
            {showSyncButton && (
              <Button onClick={handleSyncData} disabled={isSyncing || checkingStatus || !user}>
                {isSyncing ? (
                  <RotateCw className="mr-2 h-4 w-4 animate-spin" />
                ) : (
                  <Zap className="mr-2 h-4 w-4" />
                )}
                Sync Salesforce Data
              </Button>
            )}
          </div>
          <div className="mt-6">
            <h3 className="text-lg font-medium mb-1">How this works:</h3>
            <ol className="list-decimal list-inside space-y-1 text-sm text-muted-foreground">
              <li>Clicking "Connect & Authorize" redirects you to Salesforce to log in and grant access to SalesAI Navigator. Your Firebase User ID is passed as a 'state' parameter.</li>
              <li>After authorization, Salesforce redirects you back. Your application securely exchanges an authorization code for access tokens.</li>
              <li>These tokens are stored securely (currently in HTTP-only cookies for general app access; user-specific storage in Firestore is also implemented on callback).</li>
              <li>Click "Sync Salesforce Data" to simulate fetching data from your Salesforce account (currently using a predefined mock dataset for demonstration, written to your user-specific area in Firestore).</li>
            </ol>
            <p className="text-xs text-muted-foreground mt-2">
              Note: Ensure your Salesforce Connected App details (Client ID, Client Secret, Token URL, Redirect URI) are correctly set in your application's environment variables (.env for local, environment settings for deployed). Restart your server/deployment if you change these.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

export default function SalesforceIntegrationPage() {
  // Wrap with Suspense because useSearchParams() is used in the child component
  return (
    <Suspense fallback={<SalesforcePageSkeleton />}>
      <SalesforceIntegrationPageComponent />
    </Suspense>
  );
}

const SalesforcePageSkeleton = () => (
  <div className="p-6"> {/* Changed from container mx-auto p-6 */}
    <Card>
      <CardHeader>
        <Skeleton className="h-8 w-3/4 mb-2" />
        <Skeleton className="h-4 w-1/2" />
      </CardHeader>
      <CardContent className="space-y-4">
        <Skeleton className="h-4 w-full" />
        <div className="flex items-center p-4 border rounded-lg bg-secondary/30">
          <Skeleton className="h-8 w-8 rounded-full mr-4" />
          <div className="space-y-2">
            <Skeleton className="h-4 w-1/3" />
            <Skeleton className="h-3 w-2/3" />
          </div>
        </div>
        <div className="space-x-2">
          <Skeleton className="h-10 w-64" /> 
        </div>
        <div className="mt-6 space-y-2">
          <Skeleton className="h-6 w-1/4 mb-1" />
          <Skeleton className="h-4 w-full" />
          <Skeleton className="h-4 w-full" />
          <Skeleton className="h-4 w-5/6" />
          <Skeleton className="h-3 w-3/4 mt-2" />
        </div>
      </CardContent>
    </Card>
  </div>
);
