
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Database, Settings, DownloadCloud } from 'lucide-react';

export default function ZoomInfoIntegrationPage() {
  return (
    <div className="p-6"> {/* Changed from container mx-auto p-6 */}
      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-2xl font-semibold flex items-center">
              <Database className="h-7 w-7 mr-2 text-red-500" />
              ZoomInfo Integration
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-muted-foreground">
              Enhance your data with ZoomInfo's B2B database. Manage your API connection and data enrichment settings.
            </p>
            <div className="flex items-center p-4 border rounded-lg bg-secondary/30">
              <DownloadCloud className="h-8 w-8 text-purple-500 mr-4" />
              <div>
                <p className="font-semibold text-foreground">Status: API Key Required</p>
                <p className="text-sm text-muted-foreground">Enter your ZoomInfo API key to activate.</p>
              </div>
            </div>
            <div className="space-x-2">
              <Button>
                <Settings className="mr-2 h-4 w-4" /> Configure API Key
              </Button>
              <Button variant="outline">View Usage</Button>
            </div>
            <div>
              <h3 className="text-lg font-medium mt-6 mb-2">Data Enrichment</h3>
              <ul className="list-disc list-inside space-y-1 text-sm text-muted-foreground">
                <li>Automatically enrich new prospects</li>
                <li>Update existing records with latest ZoomInfo data</li>
                <li>Map ZoomInfo fields to your Salesforce fields</li>
              </ul>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
