
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Linkedin, Settings, Search } from 'lucide-react';

export default function LinkedInIntegrationPage() {
  return (
    <div className="p-6"> {/* Changed from container mx-auto p-6 */}
      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-2xl font-semibold flex items-center">
              <Linkedin className="h-7 w-7 mr-2 text-blue-600" />
              LinkedIn Integration
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-muted-foreground">
              Connect your LinkedIn account to enrich prospect data and track engagement.
            </p>
            <div className="flex items-center p-4 border rounded-lg bg-secondary/30">
              <Search className="h-8 w-8 text-orange-500 mr-4" />
              <div>
                <p className="font-semibold text-foreground">Status: Not Connected</p>
                <p className="text-sm text-muted-foreground">Connect to enable LinkedIn features.</p>
              </div>
            </div>
            <div className="space-x-2">
              <Button>
                <Linkedin className="mr-2 h-4 w-4" /> Connect LinkedIn Account
              </Button>
            </div>
            <div>
              <h3 className="text-lg font-medium mt-6 mb-2">Available Features (once connected)</h3>
              <ul className="list-disc list-inside space-y-1 text-sm text-muted-foreground">
                <li>View LinkedIn profiles from prospect records</li>
                <li>Log LinkedIn messages and InMails</li>
                <li>Import connections as prospects</li>
              </ul>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
