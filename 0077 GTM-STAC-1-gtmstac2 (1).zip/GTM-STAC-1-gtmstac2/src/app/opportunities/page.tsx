// src/app/opportunities/page.tsx
'use client';

import type { OpportunityData } from '@/types';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { format } from 'date-fns';
import { useState, useEffect } from 'react';
import { useAuth } from '@/context/AuthContext';
import { db } from '@/lib/firebase';
import { collection, query, where, getDocs } from 'firebase/firestore';
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { AlertCircle } from 'lucide-react';


export default function OpportunitiesPage() {
  const { user } = useAuth();
  const [opportunities, setOpportunities] = useState<OpportunityData[]>([]);
  // const [isLoading, setIsLoading] = useState(true);
  // const [error, setError] = useState<string | null>(null);

  // useEffect(() => {
  //   const fetchUserOpportunities = async () => {
  //     if (!user) {
  //       // setIsLoading(false);
  //       setOpportunities([]);
  //       return;
  //     }
  //     // setIsLoading(true);
  //     // setError(null);
  //     try {
  //       const opportunitiesPath = `users/${user.uid}/salesforceData/opportunities`;
  //       const opportunitiesCollectionRef = collection(db, opportunitiesPath);
  //       const querySnapshot = await getDocs(opportunitiesCollectionRef);

  //       if (!querySnapshot.empty) {
  //         const fetchedOpportunities = (querySnapshot.docs as any[]).map(doc => ({ ...doc.data() as OpportunityData, id: doc.id }));
  //         setOpportunities(fetchedOpportunities);
  //       } else {
  //         setOpportunities([]);
  //       }
  //     } catch (err: any) {
  //       console.error("Error fetching user opportunities:", err);
  //       // setError("Failed to fetch opportunities. Please ensure you are connected to the internet and try again.");
  //       setOpportunities([]);
  //     } finally {
  //       // setIsLoading(false);
  //     }
  //   };

  //   fetchUserOpportunities();
  // }, [user]);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', minimumFractionDigits: 0, maximumFractionDigits: 0 }).format(amount);
  };

  const getStageBadgeVariant = (stage: OpportunityData['stage']): "default" | "secondary" | "destructive" | "outline" => {
    if (stage === 'Closed Won') return 'default'; 
    if (stage === 'Closed Lost') return 'destructive';
    if (['Negotiation/Review', 'Proposal/Price Quote'].includes(stage)) return 'secondary'; 
    return 'outline'; 
  };

  if (!user) { 
    return (
      <div className="p-6"> {/* Changed from container mx-auto p-6 */}
        <Card>
          <CardHeader>
            <CardTitle className="text-2xl font-semibold">Opportunities</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">Please log in to view your opportunities.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  // if (isLoading) {
  //   return <div className="p-6"><p>Loading opportunities...</p></div>; // Changed from container mx-auto p-6
  // }

  // if (error) {
  //    return (
  //       <div className="p-6"> {/* Changed from container mx-auto p-6 */}
  //           <Alert variant="destructive">
  //               <AlertCircle className="h-4 w-4" />
  //               <AlertTitle>Error Fetching Opportunities</AlertTitle>
  //               <AlertDescription>{error}</AlertDescription>
  //           </Alert>
  //       </div>
  //   );
  // }
  
  return (
    <div className="p-6"> {/* Changed from container mx-auto p-6 */}
      <Card className="w-full">
        <CardHeader>
          <CardTitle className="text-2xl font-semibold">Opportunities</CardTitle>
        </CardHeader>
        <CardContent>
          {opportunities.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Opportunity Name</TableHead>
                  <TableHead>Account Name</TableHead>
                  <TableHead>Stage</TableHead>
                  <TableHead className="text-right">Amount</TableHead>
                  <TableHead className="text-right">Close Date</TableHead>
                  <TableHead>Owner</TableHead>
                  <TableHead className="text-right">Probability</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {opportunities.map((opp) => (
                  <TableRow key={opp.id}>
                    <TableCell className="font-medium">{opp.name}</TableCell>
                    <TableCell>{opp.accountName}</TableCell>
                    <TableCell>
                      <Badge variant={getStageBadgeVariant(opp.stage)}>
                        {opp.stage}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">{formatCurrency(opp.amount)}</TableCell>
                    <TableCell className="text-right">
                      {format(new Date(opp.closeDate), 'MMM d, yyyy')}
                    </TableCell>
                    <TableCell>{opp.owner}</TableCell>
                    <TableCell className="text-right">
                      {opp.probability !== undefined ? `${(opp.probability * 100).toFixed(0)}%` : 'N/A'}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <p className="text-muted-foreground">No opportunities found. Sync Salesforce data from the Integrations page.</p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
