// src/app/resources/page.tsx
'use client';

import { LandingHeader } from '@/components/landing/LandingHeader';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import Image from 'next/image';
import Link from 'next/link';
import { BookOpen, FileText, MessageSquare, PlayCircle, HelpCircle, ArrowRight, type LucideIcon } from 'lucide-react';

interface ResourceCardProps {
  icon: LucideIcon;
  title: string;
  description: string;
  linkText: string;
  linkHref: string;
  imageUrl: string;
  imageHint: string;
}

const ResourceCard: React.FC<ResourceCardProps> = ({ icon: Icon, title, description, linkText, linkHref, imageUrl, imageHint }) => (
  <Card className="bg-card shadow-lg hover:shadow-xl transition-shadow duration-300 flex flex-col overflow-hidden">
    <div className="relative w-full h-48">
        <Image src={imageUrl} alt={title} layout="fill" objectFit="cover" data-ai-hint={imageHint} />
    </div>
    <CardHeader>
      <div className="flex items-center text-primary mb-2">
        <Icon className="h-7 w-7 mr-3 flex-shrink-0" />
        <CardTitle className="text-xl font-semibold text-foreground">{title}</CardTitle>
      </div>
    </CardHeader>
    <CardContent className="flex-grow flex flex-col">
      <p className="text-muted-foreground text-sm mb-4 flex-grow">{description}</p>
      <Button variant="outline" className="mt-auto w-full" asChild>
        <Link href={linkHref}>
          {linkText} <ArrowRight className="ml-2 h-4 w-4" />
        </Link>
      </Button>
    </CardContent>
  </Card>
);

const resources = [
  {
    icon: BookOpen,
    title: "Blog & Articles",
    description: "Stay updated with the latest sales strategies, AI trends, and product updates from SalesAI Navigator.",
    linkText: "Read Our Blog",
    linkHref: "#", // Placeholder
    imageUrl: "https://placehold.co/600x400.png",
    imageHint: "writing articles"
  },
  {
    icon: FileText,
    title: "Case Studies",
    description: "Discover how businesses like yours are achieving success and transforming their sales processes with our platform.",
    linkText: "View Case Studies",
    linkHref: "#", // Placeholder
    imageUrl: "https://placehold.co/600x400.png",
    imageHint: "business success"
  },
  {
    icon: PlayCircle,
    title: "Webinars & Demos",
    description: "Join our live webinars or watch on-demand demos to see SalesAI Navigator in action and learn best practices.",
    linkText: "Watch Webinars",
    linkHref: "#", // Placeholder
    imageUrl: "https://placehold.co/600x400.png",
    imageHint: "online presentation"
  },
  {
    icon: HelpCircle,
    title: "Documentation & Guides",
    description: "Access comprehensive guides, tutorials, and API documentation to get the most out of SalesAI Navigator.",
    linkText: "Explore Docs",
    linkHref: "#", // Placeholder
    imageUrl: "https://placehold.co/600x400.png",
    imageHint: "technical support"
  },
  {
    icon: MessageSquare,
    title: "Community Forum",
    description: "Connect with other SalesAI Navigator users, share tips, ask questions, and learn from the community.",
    linkText: "Join the Community",
    linkHref: "#", // Placeholder
    imageUrl: "https://placehold.co/600x400.png",
    imageHint: "people discussion"
  },
  {
    icon: HelpCircle,
    title: "Frequently Asked Questions",
    description: "Find quick answers to common questions about our platform, features, pricing, and more.",
    linkText: "Visit FAQ",
    linkHref: "#", // Placeholder
    imageUrl: "https://placehold.co/600x400.png",
    imageHint: "question mark"
  },
];

export default function ResourcesPage() {
  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground">
      <LandingHeader />
      <main className="flex-grow container mx-auto px-4 py-12">
        <section className="text-center mb-16 pt-12">
          <h1 className="text-4xl md:text-5xl font-bold text-primary mb-4">Resources & Learning Center</h1>
          <p className="text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto">
            Everything you need to master SalesAI Navigator and elevate your sales game. Explore our guides, articles, case studies, and community resources.
          </p>
        </section>

        <section className="mb-16">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {resources.map((resource) => (
              <ResourceCard
                key={resource.title}
                icon={resource.icon}
                title={resource.title}
                description={resource.description}
                linkText={resource.linkText}
                linkHref={resource.linkHref}
                imageUrl={resource.imageUrl}
                imageHint={resource.imageHint}
              />
            ))}
          </div>
        </section>
        
        <section className="py-16 text-center bg-primary/10 rounded-lg">
          <h2 className="text-3xl font-bold text-primary mb-6">Can&apos;t Find What You&apos;re Looking For?</h2>
          <p className="text-lg text-muted-foreground max-w-xl mx-auto mb-8">
            Our support team is here to help. Reach out for personalized assistance.
          </p>
          <Button size="lg" className="text-lg py-3 px-8 shadow-lg" asChild>
            <Link href="/contact">Contact Support</Link>
          </Button>
        </section>

      </main>
      <footer className="py-8 border-t border-border/20 bg-background">
        <div className="container mx-auto text-center text-muted-foreground text-sm">
          &copy; {new Date().getFullYear()} SalesAI Navigator. All rights reserved.
        </div>
      </footer>
    </div>
  );
}
