// src/app/layout.tsx
'use client'; 

import type { Metadata } from 'next'; 
import { Geist, Geist_Mono } from 'next/font/google';
import './globals.css';
import { Toaster } from "@/components/ui/toaster";
import { SidebarProvider } from '@/components/ui/sidebar';
import AppHeader from '@/components/layout/AppHeader';
import AppSidebar from '@/components/layout/AppSidebar';
// Removed TodayTasksPanel import
import { AuthProvider, useAuth } from '@/context/AuthContext';
import { usePathname } from 'next/navigation';
import { Loader2 } from 'lucide-react'; 
import { ThemeProvider } from '@/components/theme/ThemeProvider';

const geistSans = Geist({
  variable: '--font-geist-sans',
  subsets: ['latin'],
});

const geistMono = Geist_Mono({
  variable: '--font-geist-mono',
  subsets: ['latin'],
});

// Static metadata can still be defined here if needed for all pages
// export const metadata: Metadata = {
// title: 'Gtm Stac',
// description: 'AI Sales Intelligence Platform',
// };


function AppShellLayout({ children }: { children: React.ReactNode }) {
  const { user, loading: authLoading } = useAuth();
  const pathname = usePathname();

  // Determine if the full app shell (sidebar, header, etc.) should be shown
  const showAppShell = !!user && !['/login', '/signup'].includes(pathname);

  if (authLoading && !['/login', '/signup'].includes(pathname)) {
    // Show a full-page loader if auth state is loading and not on login/signup
    return (
      <div className="flex flex-col items-center justify-center min-h-screen bg-background text-foreground">
        <Loader2 className="h-12 w-12 animate-spin text-primary mb-4" />
        <p className="text-lg text-muted-foreground">Initializing App...</p>
      </div>
    );
  }
  
  if (showAppShell) {
    return (
      <SidebarProvider defaultOpen={false}> 
        <div className="flex min-h-screen bg-background">
          <AppSidebar />
          <div className="flex flex-1 flex-col overflow-hidden">
            <AppHeader />
            {/* Removed TodayTasksPanel from here */}
            <main className="flex-1 overflow-y-auto bg-background">
              {children}
            </main>
          </div>
        </div>
      </SidebarProvider>
    );
  }

  // For landing page (unauthenticated root), login, signup: render children directly
  return <>{children}</>;
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={`${geistSans.variable} ${geistMono.variable} antialiased`} suppressHydrationWarning={true}>
        <ThemeProvider
          attribute="class"
          defaultTheme="system"
          enableSystem
          disableTransitionOnChange
        >
          <AuthProvider>
            <AppShellLayout>{children}</AppShellLayout>
          </AuthProvider>
          <Toaster />
        </ThemeProvider>
      </body>
    </html>
  );
}
