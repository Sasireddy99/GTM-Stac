
import type { GenerateProspectSummaryOutput } from '@/ai/flows/generate-prospect-summary';
import type { RecommendNextStepsOutput } from '@/ai/flows/recommend-next-steps';
import type { LucideIcon as LucideIconType } from 'lucide-react'; // Renamed to avoid conflict

export interface SalesforceRecord {
  id: string;
  name: string; // Prospect or Company Name
  contactPerson?: string;
  email?: string;
  phone?: string;
  status?: 'Lead' | 'Contacted' | 'Qualified' | 'Proposal Sent' | 'Customer' | 'Lost';
  lastContacted?: string; // ISO Date string
  industry?: string;
  annualRevenue?: number;
  employeeCount?: number;
  source?: string; // e.g., 'Website', 'Referral', 'Cold Call'
  notes?: string; // Internal Salesforce notes
  website?: string;
  address?: {
    street?: string;
    city?: string;
    state?: string;
    postalCode?: string;
    country?: string;
  };
}

export type ProspectSummary = GenerateProspectSummaryOutput;
export type NextSteps = RecommendNextStepsOutput;

// New types for Gtm Stac UI
export type TaskType = "Call" | "Email" | "LinkedIn" | "Task" | "Meeting";

export interface TaskItemData {
  id: string;
  title: string;
  description: string;
  type: TaskType;
  time: string;
  completed: boolean;
  assignee?: string;
  dueDate?: string;
}

export interface ActivityStatData {
  id: string;
  title: string;
  value: string;
  change: string;
  changeType: 'positive' | 'negative' | 'neutral';
  icon: LucideIconType; // Use the renamed type
}

export interface RecentProspectData {
  id: string;
  name: string;
  contactName: string;
  email: string;
  status: string;
  avatarUrl?: string; // placeholder like https://placehold.co/40x40.png
  dataAiHint?: string;
}

export interface NavItem {
  href: string;
  label: string;
  icon: LucideIconType; // Use the renamed type
  isActive?: boolean; // Optional: for highlighting active link
}

export interface OpportunityData {
  id: string;
  name: string;
  accountName: string;
  stage: 'Prospecting' | 'Qualification' | 'Needs Analysis' | 'Value Proposition' | 'Proposal/Price Quote' | 'Negotiation/Review' | 'Closed Won' | 'Closed Lost';
  amount: number;
  closeDate: string; // ISO Date string
  owner: string;
  probability?: number; // Percentage e.g. 0.9 for 90%
}


// Export LucideIcon if it's intended to be used elsewhere directly
export type LucideIcon = LucideIconType;

