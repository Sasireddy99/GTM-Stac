// This component is no longer directly used by the main dashboard page in the new Gtm Stac UI.
// The search functionality for "AI Sales Intelligence" is now part of AiSalesIntelligenceSection.tsx.
// This file can be kept for potential future use on other pages or removed if not needed.

'use client';

import type { FormEvent } from 'react';
import { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Search } from 'lucide-react';

interface ProspectSearchProps {
  onSearch: (searchTerm: string) => void;
  isLoading: boolean;
}

const ProspectSearch: React.FC<ProspectSearchProps> = ({ onSearch, isLoading }) => {
  const [searchTerm, setSearchTerm] = useState('');

  const handleSubmit = (event: FormEvent) => {
    event.preventDefault();
    if (searchTerm.trim()) {
      onSearch(searchTerm.trim());
    }
  };

  return (
    <form onSubmit={handleSubmit} className="flex w-full max-w-2xl items-center space-x-2">
      <Input
        type="text"
        placeholder="Search for a prospect or company..."
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
        className="flex-grow text-base"
        aria-label="Search prospects or companies"
        disabled={isLoading}
      />
      <Button type="submit" variant="default" disabled={isLoading} aria-label="Search">
        {isLoading ? (
          <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-primary-foreground" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
          </svg>
        ) : (
          <Search className="h-5 w-5" />
        )}
        <span className="ml-2 hidden sm:inline">{isLoading ? 'Searching...' : 'Search'}</span>
      </Button>
    </form>
  );
};

export default ProspectSearch;
