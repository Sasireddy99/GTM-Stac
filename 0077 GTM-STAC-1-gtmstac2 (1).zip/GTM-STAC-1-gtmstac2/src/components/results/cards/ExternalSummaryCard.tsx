
import type { ProspectSummary } from '@/types';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Lightbulb, BookOpenText, AlertCircle, Sparkles } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

interface ExternalSummaryCardProps {
  summary: ProspectSummary | null | undefined; // Allow null or undefined
  prospectName: string;
}

// Define the specific error messages our flows might return
const SUMMARY_ERROR_MESSAGE = "Could not generate summary at this time. Please try again later.";
const INSIGHTS_ERROR_MESSAGE = "Could not generate insights at this time. Please try again later.";

const ExternalSummaryCard: React.FC<ExternalSummaryCardProps> = ({ summary, prospectName }) => {
  if (!summary) {
    return (
      <Card className="w-full shadow-lg">
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle className="text-xl text-primary flex items-center">
                <BookOpenText className="mr-3 h-6 w-6" /> External Summary
            </CardTitle>
            <Badge variant="outline" className="text-xs">
              <Sparkles className="h-3 w-3 mr-1 text-primary" /> Gemini AI
            </Badge>
          </div>
          <CardDescription className="text-sm">AI-generated overview for {prospectName}.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center text-destructive text-sm mt-1">
            <AlertCircle className="h-4 w-4 mr-2 flex-shrink-0" />
            <span>Could not load external summary information. An error may have occurred while generating it.</span>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="w-full shadow-lg">
      <CardHeader>
        <div className="flex justify-between items-center">
          <CardTitle className="text-xl text-primary flex items-center">
              <BookOpenText className="mr-3 h-6 w-6" /> External Summary
          </CardTitle>
          <Badge variant="outline" className="text-xs">
            <Sparkles className="h-3 w-3 mr-1 text-primary" /> Gemini AI
          </Badge>
        </div>
        <CardDescription className="text-sm">AI-generated overview for {prospectName} based on public information.</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <h3 className="text-lg font-semibold flex items-center mb-1">
            <BookOpenText className="h-5 w-5 mr-2 text-accent" />
            Company Overview
          </h3>
          {summary.summary === SUMMARY_ERROR_MESSAGE ? (
            <div className="flex items-center text-destructive text-sm mt-1">
              <AlertCircle className="h-4 w-4 mr-2 flex-shrink-0" />
              <span>{summary.summary}</span>
            </div>
          ) : (
            <p className="text-sm text-foreground whitespace-pre-wrap">{summary.summary || 'No summary available.'}</p>
          )}
        </div>
        <div>
          <h3 className="text-lg font-semibold flex items-center mb-1">
            <Lightbulb className="h-5 w-5 mr-2 text-accent" />
            Potential Insights & Needs
          </h3>
          {summary.insights === INSIGHTS_ERROR_MESSAGE ? (
            <div className="flex items-center text-destructive text-sm mt-1">
              <AlertCircle className="h-4 w-4 mr-2 flex-shrink-0" />
              <span>{summary.insights}</span>
            </div>
          ) : (
            <p className="text-sm text-foreground whitespace-pre-wrap">{summary.insights || 'No insights available.'}</p>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default ExternalSummaryCard;
