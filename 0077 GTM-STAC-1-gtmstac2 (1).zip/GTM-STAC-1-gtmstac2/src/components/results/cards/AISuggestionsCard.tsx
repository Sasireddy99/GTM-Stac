
import type { NextSteps } from '@/types';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { ClipboardList, Brain, AlertCircle, Sparkles } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

interface AISuggestionsCardProps {
  suggestions: NextSteps | null | undefined; // Allow null or undefined
  prospectName: string;
}

// Define the specific error messages our flows might return
const NEXT_STEPS_ERROR_MESSAGE = "Could not recommend next steps at this time. Please try again later.";
const REASONING_ERROR_MESSAGE = "AI analysis for reasoning is currently unavailable.";

const AISuggestionsCard: React.FC<AISuggestionsCardProps> = ({ suggestions, prospectName }) => {
  if (!suggestions) {
    return (
      <Card className="w-full shadow-lg bg-secondary/50">
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle className="text-xl text-primary flex items-center">
                <ClipboardList className="mr-3 h-6 w-6" /> AI Recommended Next Steps
            </CardTitle>
            <Badge variant="outline" className="text-xs">
              <Sparkles className="h-3 w-3 mr-1 text-primary" /> Gemini AI
            </Badge>
          </div>
          <CardDescription className="text-sm">AI-driven suggestions for engaging with {prospectName}.</CardDescription>
        </CardHeader>
        <CardContent>
           <div className="flex items-center text-destructive text-sm mt-1">
            <AlertCircle className="h-4 w-4 mr-2 flex-shrink-0" />
            <span>Could not load AI recommendations. An error may have occurred while generating them.</span>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="w-full shadow-lg bg-secondary/50">
      <CardHeader>
        <div className="flex justify-between items-center">
          <CardTitle className="text-xl text-primary flex items-center">
              <ClipboardList className="mr-3 h-6 w-6" /> AI Recommended Next Steps
          </CardTitle>
          <Badge variant="outline" className="text-xs">
            <Sparkles className="h-3 w-3 mr-1 text-primary" /> Gemini AI
          </Badge>
        </div>
        <CardDescription className="text-sm">AI-driven suggestions for engaging with {prospectName}.</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <h3 className="text-lg font-semibold flex items-center mb-1">
            <ClipboardList className="h-5 w-5 mr-2 text-accent" />
            Next Actions
          </h3>
          {suggestions.nextSteps === NEXT_STEPS_ERROR_MESSAGE ? (
             <div className="flex items-center text-destructive text-sm mt-1">
              <AlertCircle className="h-4 w-4 mr-2 flex-shrink-0" />
              <span>{suggestions.nextSteps}</span>
            </div>
          ) : (
            <p className="text-sm text-foreground whitespace-pre-wrap">{suggestions.nextSteps || 'No specific next steps recommended at this time.'}</p>
          )}
        </div>
        <div>
          <h3 className="text-lg font-semibold flex items-center mb-1">
            <Brain className="h-5 w-5 mr-2 text-accent" />
            Reasoning
          </h3>
           {suggestions.reasoning === REASONING_ERROR_MESSAGE ? (
             <div className="flex items-center text-destructive text-sm mt-1">
              <AlertCircle className="h-4 w-4 mr-2 flex-shrink-0" />
              <span>{suggestions.reasoning}</span>
            </div>
          ) : (
            <p className="text-sm text-foreground whitespace-pre-wrap">{suggestions.reasoning || 'No reasoning provided.'}</p>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default AISuggestionsCard;
