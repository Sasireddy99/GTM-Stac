import type { SalesforceRecord } from '@/types';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Briefcase, Users, Mail, Phone, DollarSign, BarChart3, Info, CalendarDays, ExternalLink } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { format } from 'date-fns';

interface SalesforceInfoCardProps {
  record: SalesforceRecord;
}

const DataPoint: React.FC<{ icon: React.ElementType; label: string; value?: string | number | null; children?: React.ReactNode }> = ({ icon: Icon, label, value, children }) => {
  if (!value && !children) return null;
  return (
    <div className="flex items-start space-x-3 py-2">
      <Icon className="h-5 w-5 text-primary mt-1 flex-shrink-0" />
      <div>
        <p className="text-sm font-medium text-muted-foreground">{label}</p>
        {value && <p className="text-sm text-foreground">{value}</p>}
        {children}
      </div>
    </div>
  );
};


const SalesforceInfoCard: React.FC<SalesforceInfoCardProps> = ({ record }) => {
  return (
    <Card className="w-full shadow-lg">
      <CardHeader>
        <div className="flex items-center justify-between">
            <CardTitle className="text-2xl text-primary flex items-center">
                <Briefcase className="mr-3 h-7 w-7" /> Salesforce Record
            </CardTitle>
            {record.status && <Badge variant={record.status === 'Customer' ? 'default' : 'secondary'} className="capitalize">{record.status}</Badge>}
        </div>
        <CardDescription>Detailed information from Salesforce for {record.name}.</CardDescription>
      </CardHeader>
      <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-4">
        <DataPoint icon={Info} label="Company Name" value={record.name} />
        {record.contactPerson && <DataPoint icon={Users} label="Contact Person" value={record.contactPerson} />}
        {record.email && <DataPoint icon={Mail} label="Email" value={record.email} />}
        {record.phone && <DataPoint icon={Phone} label="Phone" value={record.phone} />}
        {record.industry && <DataPoint icon={BarChart3} label="Industry" value={record.industry} />}
        {record.annualRevenue && <DataPoint icon={DollarSign} label="Annual Revenue" value={`$${record.annualRevenue.toLocaleString()}`} />}
        {record.employeeCount && <DataPoint icon={Users} label="Employee Count" value={record.employeeCount.toString()} />}
        {record.source && <DataPoint icon={Briefcase} label="Source" value={record.source} />}
        {record.lastContacted && (
          <DataPoint icon={CalendarDays} label="Last Contacted" value={format(new Date(record.lastContacted), 'PPP')} />
        )}
        {record.website && (
            <DataPoint icon={ExternalLink} label="Website">
                <a href={record.website.startsWith('http') ? record.website : `https://${record.website}`} target="_blank" rel="noopener noreferrer" className="text-sm text-primary hover:underline break-all">
                    {record.website}
                </a>
            </DataPoint>
        )}
        {record.address && (
            <DataPoint icon={Info} label="Address">
                <p className="text-sm text-foreground">
                    {record.address.street && `${record.address.street}, `}
                    {record.address.city && `${record.address.city}, `}
                    {record.address.state && `${record.address.state} `}
                    {record.address.postalCode && `${record.address.postalCode} `}
                    {record.address.country && record.address.country}
                </p>
            </DataPoint>
        )}
        {record.notes && (
          <div className="md:col-span-2">
            <DataPoint icon={Info} label="Notes">
              <p className="text-sm text-foreground whitespace-pre-wrap">{record.notes}</p>
            </DataPoint>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default SalesforceInfoCard;
