// This component is no longer directly used by the main dashboard page in the new Gtm Stac UI.
// The prospect details might be displayed on a separate page or modal in the future.
// This file can be kept for potential future use or removed if not needed.

import type { SalesforceRecord, ProspectSummary, NextSteps } from '@/types';
import SalesforceInfoCard from './cards/SalesforceInfoCard';
import ExternalSummaryCard from './cards/ExternalSummaryCard';
import AISuggestionsCard from './cards/AISuggestionsCard';
import { Skeleton } from '@/components/ui/skeleton';
import { AlertCircle, Info } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

interface ProspectDetailsViewProps {
  searchTerm: string;
  salesforceRecord: SalesforceRecord | null | undefined;
  prospectSummary: ProspectSummary | null | undefined;
  nextSteps: NextSteps | null | undefined;
  isLoading: boolean;
  error: string | null;
  searchPerformed: boolean;
}

const LoadingSkeleton: React.FC = () => (
  <div className="space-y-6">
    <CardSkeleton />
    <CardSkeleton />
  </div>
);

const CardSkeleton: React.FC = () => (
  <div className="p-6 border rounded-lg shadow-sm bg-card">
    <Skeleton className="h-8 w-3/4 mb-4" />
    <Skeleton className="h-4 w-full mb-2" />
    <Skeleton className="h-4 w-5/6 mb-2" />
    <Skeleton className="h-4 w-full" />
  </div>
);


const ProspectDetailsView: React.FC<ProspectDetailsViewProps> = ({
  searchTerm,
  salesforceRecord,
  prospectSummary,
  nextSteps,
  isLoading,
  error,
  searchPerformed
}) => {
  if (isLoading) {
    return <LoadingSkeleton />;
  }

  if (error) {
    return (
      <Alert variant="destructive" className="mt-6">
        <AlertCircle className="h-4 w-4" />
        <AlertTitle>Error</AlertTitle>
        <AlertDescription>{error}</AlertDescription>
      </Alert>
    );
  }
  
  if (!searchPerformed) {
     return (
        <div className="text-center py-10">
          <Info className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
          <p className="text-lg text-muted-foreground">
            Enter a prospect or company name above to get started.
          </p>
          <p className="text-sm text-muted-foreground mt-2">
            SalesAI Navigator will fetch information from Salesforce and public sources.
          </p>
        </div>
    );
  }

  if (!prospectSummary && !salesforceRecord) {
    return (
      <div className="text-center py-10">
          <AlertCircle className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
          <p className="text-lg text-muted-foreground">
            No information found for &quot;{searchTerm}&quot;.
          </p>
          <p className="text-sm text-muted-foreground mt-2">
            Please try a different search term or check your spelling.
          </p>
      </div>
    );
  }
  

  return (
    <div className="space-y-6 mt-6">
      {salesforceRecord && <SalesforceInfoCard record={salesforceRecord} />}
      {prospectSummary && <ExternalSummaryCard summary={prospectSummary} prospectName={searchTerm} />}
      {salesforceRecord && nextSteps && <AISuggestionsCard suggestions={nextSteps} prospectName={searchTerm} />}
      {!salesforceRecord && prospectSummary && (
         <Alert className="mt-4">
            <Info className="h-4 w-4" />
            <AlertTitle>Salesforce Record Not Found</AlertTitle>
            <AlertDescription>
                No matching record for &quot;{searchTerm}&quot; was found in Salesforce. Displaying public information only.
            </AlertDescription>
        </Alert>
      )}
    </div>
  );
};

export default ProspectDetailsView;
