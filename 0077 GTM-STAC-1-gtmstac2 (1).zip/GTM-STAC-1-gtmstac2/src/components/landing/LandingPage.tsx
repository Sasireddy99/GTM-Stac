
'use client';

import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ArrowRight, Brain, PieChart, Zap, Users, UserCheck, Target, LineChart, Briefcase, Megaphone, Headphones, BarChartBig, FileText, Settings, ShieldCheck, Building, Handshake, Cloud, Linkedin, Database, Search } from 'lucide-react';
import type { LucideIcon } from '@/types';
import Image from 'next/image';
import { LandingHeader } from './LandingHeader'; // Import the refactored header


interface FeatureCardProps {
  icon: LucideIcon;
  title: string;
  description: string;
}

const FeatureCard: React.FC<FeatureCardProps> = ({ icon: Icon, title, description }) => (
  <Card className="bg-card shadow-lg hover:shadow-xl transition-shadow duration-300 flex flex-col">
    <CardHeader>
      <div className="flex items-center text-primary mb-3">
        <Icon className="h-7 w-7 mr-3" />
        <CardTitle className="text-xl font-semibold text-foreground">{title}</CardTitle>
      </div>
    </CardHeader>
    <CardContent className="flex-grow">
      <p className="text-muted-foreground text-sm">{description}</p>
    </CardContent>
  </Card>
);

interface BenefitCardProps {
  title: string;
  description: string;
}
const BenefitCard: React.FC<BenefitCardProps> = ({ title, description }) => (
  <Card className="bg-card shadow-lg hover:shadow-xl transition-shadow duration-300 flex flex-col text-center items-center">
    <CardHeader>
      <CardTitle className="text-xl font-semibold text-foreground">{title}</CardTitle>
    </CardHeader>
    <CardContent className="flex-grow">
      <p className="text-muted-foreground text-sm">{description}</p>
    </CardContent>
  </Card>
);


export default function LandingPage() {
  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground">
      <LandingHeader />

      <main className="flex-grow">
        {/* Hero Section */}
        <section className="relative pt-20 pb-10 md:pt-32 md:pb-16 lg:pt-40 lg:pb-20 bg-background text-center">
          <div className="relative z-10 container mx-auto px-4">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold mb-6 tracking-tight text-foreground">
              Supercharge Your Sales with AI
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto mb-8">
              SalesAI Navigator is the intelligent sales assistant that empowers your team to close more deals, faster.
              Leverage AI to automate tasks, gain deep insights, and personalize your outreach.
            </p>
            <div className="space-x-4">
              <Link href="/signup" passHref>
                <Button size="lg" variant="default" className="text-lg py-3 px-8 shadow-lg">
                  Get Started Free
                </Button>
              </Link>
              <Link href="#features" passHref>
                <Button variant="outline" size="lg" className="text-lg py-3 px-8 shadow-lg text-primary border-primary hover:bg-primary/10 hover:text-primary">
                  Learn More <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
            </div>
          </div>
        </section>

        {/* Key Features Section */}
        <section id="features" className="pt-8 pb-16 lg:pt-12 lg:pb-24 bg-card/5">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12 lg:mb-16">
              <h2 className="text-3xl md:text-4xl font-bold mb-3 text-foreground">
                Unlock Your Sales Potential
              </h2>
              <p className="text-md md:text-lg text-muted-foreground max-w-3xl mx-auto">
                Discover how our intelligent assistant can revolutionize your sales process and help you
                achieve unprecedented results.
              </p>
            </div>
            <div className="grid md:grid-cols-3 gap-8">
              <FeatureCard
                icon={Brain}
                title="AI-Powered Insights"
                description="Get actionable intelligence on prospects, companies, and market trends to tailor your approach."
              />
              <FeatureCard
                icon={Zap}
                title="Workflow Automation"
                description="Automate repetitive tasks like data entry, follow-up reminders, and email drafting."
              />
              <FeatureCard
                icon={PieChart}
                title="Personalized Outreach"
                description="Craft compelling, data-driven messages that resonate with each prospect's unique needs."
              />
            </div>
          </div>
        </section>

        {/* Why Choose SalesAI Navigator? Section */}
        <section className="py-16 lg:py-24 bg-background">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12 lg:mb-16">
              <h2 className="text-3xl md:text-4xl font-bold mb-3 text-foreground">Why Choose SalesAI Navigator?</h2>
              <p className="text-md md:text-lg text-muted-foreground max-w-3xl mx-auto">
                We provide the tools and intelligence your sales team needs to excel in today's competitive market.
              </p>
            </div>
            <div className="grid md:grid-cols-3 gap-8">
              <BenefitCard
                title="Increase Efficiency"
                description="Spend less time on manual tasks and more time selling. Our AI handles the repetitive work so your team can focus on building relationships and closing deals."
              />
              <BenefitCard
                title="Boost Conversion Rates"
                description="Identify the most promising leads and engage them with personalized communication at the right time, significantly improving your chances of success."
              />
              <BenefitCard
                title="Gain Deeper Insights"
                description="Understand your customers and market dynamics like never before. Make data-driven decisions to optimize your sales strategy and outperform the competition."
              />
            </div>
          </div>
        </section>
        
        {/* A Platform for Your Entire Go-To-Market Team */}
        <section className="py-16 lg:py-24 bg-card/5">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12 lg:mb-16">
              <h2 className="text-3xl md:text-4xl font-bold mb-3 text-foreground">A Platform for Your Entire Go-To-Market Team</h2>
              <p className="text-md md:text-lg text-muted-foreground max-w-3xl mx-auto">
                Empowering every role in your revenue engine with tailored AI assistance.
              </p>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
              <FeatureCard
                icon={Search}
                title="AI-Powered Search & Discovery"
                description="Uncover comprehensive prospect profiles by leveraging AI to search and synthesize data from Salesforce, LinkedIn, ZoomInfo, and the open web, ensuring you always have the most up-to-date information."
              />
              <FeatureCard
                icon={Headphones}
                title="Sales Representatives"
                description="Automate research, craft personalized emails, get next-step recommendations, and stay on top of follow-ups effortlessly."
              />
              <FeatureCard
                icon={BarChartBig}
                title="Sales Leaders"
                description="Gain pipeline visibility, forecast accurately, identify coaching opportunities, and optimize team performance with data-driven insights."
              />
              <FeatureCard
                icon={Megaphone}
                title="Marketing Teams"
                description="Understand lead quality, refine targeting, generate compelling content ideas, and align messaging with sales efforts."
              />
              <FeatureCard
                  icon={Settings} 
                  title="Account Management"
                  description="Identify upsell/cross-sell opportunities, monitor account health, and personalize client communication for retention."
              />
              <FeatureCard
                  icon={UserCheck}
                  title="Customer Success"
                  description="Proactively address customer needs, identify churn risks, and personalize support interactions for improved satisfaction."
              />
            </div>
          </div>
        </section>

        {/* All Your GTM Stack in One Place Section */}
         <section className="py-16 lg:py-24 bg-background">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12 lg:mb-16">
              <h2 className="text-3xl md:text-4xl font-bold mb-3 text-foreground">
                All Your GTM Stack in One Place
              </h2>
              <p className="text-md md:text-lg text-muted-foreground max-w-2xl mx-auto">
                SalesAI Navigator integrates with your favorite tools, bringing all your sales intelligence together.
              </p>
            </div>
            <div className="flex flex-wrap justify-center items-center gap-8 md:gap-12 text-muted-foreground">
              <div className="flex items-center space-x-2 text-2xl font-semibold">
                <Cloud className="h-10 w-10 text-blue-500" /> <span>Salesforce</span>
              </div>
              <div className="flex items-center space-x-2 text-2xl font-semibold">
                <Linkedin className="h-10 w-10 text-blue-700" /> <span>LinkedIn Sales Nav</span>
              </div>
              <div className="flex items-center space-x-2 text-2xl font-semibold">
                <Database className="h-10 w-10 text-red-500" /> <span>ZoomInfo</span>
              </div>
               <div className="flex items-center space-x-2 text-2xl font-semibold">
                <Briefcase className="h-10 w-10 text-green-500" /> <span>HubSpot</span>
              </div>
               <div className="flex items-center space-x-2 text-2xl font-semibold">
                <ShieldCheck className="h-10 w-10 text-purple-500" /> <span>Outreach</span>
              </div>
            </div>
          </div>
        </section>

        {/* Call to Action Section */}
        <section className="py-16 lg:py-24 bg-gray-800 text-white">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">
              Ready to Elevate Your Sales Game?
            </h2>
            <p className="text-lg md:text-xl text-gray-300 max-w-xl mx-auto mb-8">
              Join thousands of sales professionals transforming their workflow with SalesAI Navigator.
              Start your free trial today or talk to our experts.
            </p>
            <div className="space-x-4">
              <Link href="/signup" passHref>
                <Button size="lg" className="text-lg py-3 px-8 bg-white text-gray-800 hover:bg-gray-200 shadow-lg">
                  Get Started for Free
                </Button>
              </Link>
              <Link href="/" passHref> {/* Placeholder link for "Request a Demo" */}
                <Button size="lg" className="text-lg py-3 px-8 bg-white text-gray-800 hover:bg-gray-200 shadow-lg">
                  Request a Demo
                </Button>
              </Link>
            </div>
          </div>
        </section>
      </main>

      <footer className="py-8 border-t border-border/20 bg-background">
        <div className="container mx-auto text-center text-muted-foreground text-sm">
          &copy; {new Date().getFullYear()} SalesAI Navigator. All rights reserved.
        </div>
      </footer>
    </div>
  );
}
