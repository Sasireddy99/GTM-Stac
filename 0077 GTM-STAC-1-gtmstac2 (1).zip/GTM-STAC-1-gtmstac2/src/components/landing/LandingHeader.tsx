// src/components/landing/LandingHeader.tsx
'use client';

import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { ArrowRight } from 'lucide-react';

export const LandingHeader = () => {
  const navLinks = [
    { href: "/product", label: "Product" },
    { href: "/solutions", label: "Solutions" },
    { href: "/resources", label: "Resources" },
    { href: "/company", label: "Company" },
  ];

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto flex h-16 items-center justify-between px-4 sm:px-6 lg:px-8">
        <Link href="/" className="flex flex-col items-start group mr-6 flex-shrink-0">
          <span className="text-2xl font-bold text-primary group-hover:text-primary/90 transition-colors">
            GTM Stac
          </span>
          <span className="text-xs text-muted-foreground group-hover:text-muted-foreground/80 transition-colors -mt-0.5">
            Your Sales AI Assistant
          </span>
        </Link>
        
        <nav className="hidden md:flex flex-grow items-center justify-center space-x-4 lg:space-x-6">
          {navLinks.map((link) => (
            <Link
              key={link.label}
              href={link.href}
              className="text-sm font-medium text-muted-foreground transition-colors hover:text-primary px-2 py-1 rounded-md"
            >
              {link.label}
            </Link>
          ))}
        </nav>

        <div className="flex items-center space-x-2 flex-shrink-0">
          <Button variant="ghost" className="text-primary hover:bg-primary/10" asChild>
            <Link href="/login">Login</Link>
          </Button>
          <Button variant="default" asChild>
            <Link href="/signup">
              Sign Up <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
        </div>
      </div>
    </header>
  );
};
