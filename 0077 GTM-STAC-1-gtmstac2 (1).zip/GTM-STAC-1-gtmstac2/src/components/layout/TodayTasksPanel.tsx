'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { Plus, CalendarDays, Mail, Phone, Linkedin, ClipboardCheck } from 'lucide-react'; // Added Linkedin
import type { TaskItemData, TaskType, LucideIcon } from '@/types';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'; // Added Card components

const initialTasks: TaskItemData[] = [
  { id: '1', title: 'Follow up with John from Acme Inc.', description: 'Discuss product demo next week', type: 'Call', time: '3:30 PM', completed: false },
  { id: '2', title: 'Send product specs to TechCorp team', description: 'Include pricing options', type: 'Email', time: '5:00 PM', completed: false },
  { id: '3', title: 'Connect with Lisa on LinkedIn', description: 'New VP of Sales at GlobalTech', type: 'LinkedIn', time: '6:30 PM', completed: true },
  { id: '4', title: 'Prepare proposal for MarketEdge', description: 'Review with sales team before sending', type: 'Task', time: '9:00 PM', completed: false },
  { id: '5', title: 'Schedule demo with Quantum Solutions', description: 'Coordinate with implementation team', type: 'Meeting', time: '9:45 PM', completed: false },
];

const taskTypeColors: Record<TaskType, string> = {
  Call: 'bg-blue-100 text-blue-700 border-blue-300 dark:bg-blue-900/50 dark:text-blue-300 dark:border-blue-700',
  Email: 'bg-purple-100 text-purple-700 border-purple-300 dark:bg-purple-900/50 dark:text-purple-300 dark:border-purple-700',
  LinkedIn: 'bg-sky-100 text-sky-700 border-sky-300 dark:bg-sky-900/50 dark:text-sky-300 dark:border-sky-700',
  Task: 'bg-amber-100 text-amber-700 border-amber-300 dark:bg-amber-900/50 dark:text-amber-300 dark:border-amber-700',
  Meeting: 'bg-green-100 text-green-700 border-green-300 dark:bg-green-900/50 dark:text-green-300 dark:border-green-700',
};

const taskTypeIcons: Record<TaskType, LucideIcon> = {
    Call: Phone,
    Email: Mail,
    LinkedIn: Linkedin,
    Task: ClipboardCheck,
    Meeting: CalendarDays,
};


const TaskListItem: React.FC<{ task: TaskItemData; onToggle: (id: string) => void }> = ({ task, onToggle }) => {
  const TypeIcon = taskTypeIcons[task.type];
  return (
    <div className="flex items-start space-x-3 py-3 border-b border-border last:border-b-0">
      <Checkbox
        id={`task-${task.id}`}
        checked={task.completed}
        onCheckedChange={() => onToggle(task.id)}
        className="mt-1"
        aria-label={`Mark task ${task.title} as ${task.completed ? 'incomplete' : 'complete'}`}
      />
      <div className="flex-1">
        <div className="flex justify-between items-start">
          <label htmlFor={`task-${task.id}`} className={`text-sm font-medium ${task.completed ? 'line-through text-muted-foreground' : 'text-foreground'}`}>
            {task.title}
          </label>
          <span className={`text-xs ${task.completed ? 'text-muted-foreground' : 'text-foreground'}`}>{task.time}</span>
        </div>
        <p className={`text-xs mt-0.5 ${task.completed ? 'line-through text-muted-foreground' : 'text-muted-foreground'}`}>{task.description}</p>
        <Badge variant="outline" className={`mt-1 text-xs font-normal py-0.5 px-1.5 ${taskTypeColors[task.type]}`}>
          <TypeIcon className="h-3 w-3 mr-1" />
          {task.type}
        </Badge>
      </div>
    </div>
  );
};

// Renamed from TodayTasksPanel to TodaysTasksCard to reflect its new role
const TodaysTasksCard = () => { 
  const [tasks, setTasks] = useState<TaskItemData[]>(initialTasks);

  const handleToggleTask = (id: string) => {
    setTasks(prevTasks =>
      prevTasks.map(task =>
        task.id === id ? { ...task, completed: !task.completed } : task
      )
    );
  };

  return (
    <Card className="w-full shadow-sm">
      <CardHeader>
        <div className="flex justify-between items-center">
          <CardTitle className="text-xl font-semibold text-foreground">Today&apos;s Tasks</CardTitle>
          <Button variant="outline" size="sm">
            <Plus className="h-4 w-4 mr-1.5" />
            Add Task
          </Button>
        </div>
      </CardHeader>
      <CardContent className="p-0"> {/* Adjusted padding if tasks list has its own */}
        <ScrollArea className="h-[300px] md:h-[400px]"> {/* Added a fixed height for scrollability within card */}
          <div className="p-4 space-y-0">
            {tasks.length > 0 ? (
              tasks.map(task => (
                <TaskListItem key={task.id} task={task} onToggle={handleToggleTask} />
              ))
            ) : (
              <p className="text-sm text-muted-foreground text-center py-4">No tasks for today.</p>
            )}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
};

export default TodaysTasksCard; // Updated export name
