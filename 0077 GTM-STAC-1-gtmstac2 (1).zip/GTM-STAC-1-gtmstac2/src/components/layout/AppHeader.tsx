// src/components/layout/AppHeader.tsx
'use client';

import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Bell, Settings, Moon, LogOut, UserCircle, ExternalLink, Sun, Laptop, PanelLeft } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
  DropdownMenuSub,
  DropdownMenuSubTrigger,
  DropdownMenuPortal,
  DropdownMenuSubContent,
} from "@/components/ui/dropdown-menu";
import { useAuth } from '@/context/AuthContext';
import { signOut } from 'firebase/auth';
import { auth } from '@/lib/firebase';
import { Skeleton } from '@/components/ui/skeleton';
import { useTheme } from 'next-themes'; 
import { useSidebar } from '@/components/ui/sidebar';

const AppHeader = () => {
  const { user, loading } = useAuth();
  const router = useRouter();
  const { setTheme } = useTheme(); 
  const { toggleSidebar, isMobile } = useSidebar();

  const handleLogout = async () => {
    try {
      await signOut(auth);
      router.push('/login'); 
    } catch (error) {
      console.error("Logout Error:", error);
    }
  };

  return (
    <header className="bg-card border-b border-border h-16 flex items-center px-6 shrink-0">
      {/* Left side: Mobile Sidebar Toggle */}
      <div className="flex-shrink-0"> {/* Added flex-shrink-0 to prevent this div from shrinking if not needed */}
        {isMobile && (
          <Button
            variant="ghost"
            size="icon"
            onClick={toggleSidebar}
            aria-label="Toggle sidebar"
            className="mr-2" // Added mr-2 for spacing if mobile toggle is present
          >
            <PanelLeft className="h-5 w-5" />
          </Button>
        )}
      </div>
      
      {/* Spacer to push icons to the right */}
      <div className="flex-grow" />

      {/* Right-aligned icons */}
      <div className="flex items-center space-x-3">
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon" aria-label="Toggle theme">
              <Sun className="h-5 w-5 rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
              <Moon className="absolute h-5 w-5 rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
              <span className="sr-only">Toggle theme</span>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem onClick={() => setTheme('light')}>
              <Sun className="mr-2 h-4 w-4" />
              Light
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => setTheme('dark')}>
              <Moon className="mr-2 h-4 w-4" />
              Dark
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => setTheme('system')}>
              <Laptop className="mr-2 h-4 w-4" />
              System
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>

        <Button variant="ghost" size="icon" aria-label="Notifications">
          <Bell className="h-5 w-5" />
        </Button>
        
        <DropdownMenu>
            <DropdownMenuTrigger asChild>
                 <Button variant="ghost" size="icon" aria-label="Settings">
                    <Settings className="h-5 w-5" />
                </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
                <DropdownMenuLabel>General Settings</DropdownMenuLabel>
                <DropdownMenuItem>Preferences</DropdownMenuItem>
                <DropdownMenuItem>Integrations</DropdownMenuItem>
                 <DropdownMenuSeparator />
                <DropdownMenuSub>
                    <DropdownMenuSubTrigger>
                        User Management
                    </DropdownMenuSubTrigger>
                    <DropdownMenuPortal>
                        <DropdownMenuSubContent>
                        <DropdownMenuItem>Invite Users</DropdownMenuItem>
                        <DropdownMenuItem>Roles & Permissions</DropdownMenuItem>
                        </DropdownMenuSubContent>
                    </DropdownMenuPortal>
                </DropdownMenuSub>
                <DropdownMenuItem>Help Center</DropdownMenuItem>
            </DropdownMenuContent>
        </DropdownMenu>

        {loading ? (
          <Skeleton className="h-8 w-8 rounded-full" />
        ) : user ? (
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="relative h-8 w-8 rounded-full">
                <Avatar className="h-8 w-8">
                  {user.photoURL ? (
                    <AvatarImage src={user.photoURL} alt={user.displayName || 'User Avatar'} data-ai-hint="profile person" />
                  ) : null}
                  <AvatarFallback>
                    {user.displayName ? user.displayName.charAt(0).toUpperCase() : 
                     user.email ? user.email.charAt(0).toUpperCase() : <UserCircle size={20} />}
                  </AvatarFallback>
                </Avatar>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuLabel>
                {user.displayName || user.email || 'My Account'}
              </DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem>Profile</DropdownMenuItem>
              <DropdownMenuItem>Account Settings</DropdownMenuItem> 
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={handleLogout} className="text-destructive focus:bg-destructive/10 focus:text-destructive">
                <LogOut className="mr-2 h-4 w-4" />
                Log out
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        ) : (
          <div className="flex items-center space-x-2">
            <Button variant="outline" size="sm" asChild>
              <Link href="/login">
                <ExternalLink className="mr-2 h-4 w-4" /> Login
              </Link>
            </Button>
            <Button variant="default" size="sm" asChild>
               <Link href="/signup">
                Sign Up
               </Link>
            </Button>
          </div>
        )}
      </div>
    </header>
  );
};

export default AppHeader;
