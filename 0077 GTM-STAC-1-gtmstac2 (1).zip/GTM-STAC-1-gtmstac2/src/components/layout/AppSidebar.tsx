
'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import {
  Sidebar,
  SidebarHeader,
  SidebarContent,
  SidebarFooter,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarGroup,
  SidebarGroupLabel,
  useSidebar,
} from '@/components/ui/sidebar';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import {
  LayoutGrid,
  Users,
  FileText,
  Target,
  Cloud,
  Linkedin,
  Database,
  LifeBuoy,
  SidebarCloseIcon,
  SidebarOpenIcon,
} from 'lucide-react';
import type { NavItem } from '@/types';
import { cn } from '@/lib/utils';

const mainMenuNavItems: NavItem[] = [
  { href: '/', label: 'Dashboard', icon: LayoutGrid },
  { href: '/prospects', label: 'Prospects', icon: Users },
  { href: '/accounts', label: 'Accounts', icon: FileText },
  { href: '/opportunities', label: 'Opportunities', icon: Target },

];

const integrationNavItems: NavItem[] = [
  { href: '/integrations/salesforce', label: 'Salesforce', icon: Cloud },
  { href: '/integrations/linkedin', label: 'LinkedIn', icon: Linkedin },
  { href: '/integrations/zoominfo', label: 'ZoomInfo', icon: Database },
];

const AppSidebar = () => {
  const pathname = usePathname();
  const { state, open, toggleSidebar, isMobile } = useSidebar(); // Added isMobile

  const SidebarToggleIcon = state === 'expanded' && open ? SidebarCloseIcon : SidebarOpenIcon;

  return (
    <Sidebar collapsible="icon" side="left" variant="sidebar">
      <SidebarHeader className={cn(
        "p-3 flex items-center",
        state === 'expanded' ? "justify-between" : "justify-center"
      )}>
        <Link href="/" className={cn(
            "block", 
        )}>
          <div className={cn(
            "bg-primary text-primary-foreground py-2.5 px-3 rounded-md flex flex-col items-center justify-center transition-all duration-200 ease-in-out",
            state === 'expanded' ? "min-h-[50px]" : "min-h-[36px] text-center w-full max-w-[calc(var(--sidebar-width-icon)-1rem)]" 
          )}>
            <span className={cn(
              "font-semibold",
              state === 'expanded' ? "text-lg" : "text-xs leading-none" 
            )}>
              GTM Stac
            </span>
            {state === 'expanded' && (
              <span className="text-[10px] font-normal opacity-90 block leading-tight mt-0.5">
                Your Sales AI Assistant
              </span>
            )}
          </div>
        </Link>

        {/* Show toggle button on desktop if sidebar is collapsible, hide on mobile as header has its own */}
        {!isMobile && (
          <Button
            variant="ghost"
            size="icon"
            onClick={toggleSidebar}
            className={cn(
              "text-muted-foreground hover:text-foreground",
            )}
            aria-label={open ? "Collapse sidebar" : "Expand sidebar"}
          >
            <SidebarToggleIcon className="h-5 w-5" />
          </Button>
        )}
      </SidebarHeader>

      <SidebarContent className="p-2 flex-grow">
        <SidebarGroup>
          <SidebarGroupLabel className="group-data-[collapsible=icon]:hidden">MAIN MENU</SidebarGroupLabel>
          <SidebarMenu>
            {mainMenuNavItems.map((item) => (
              <SidebarMenuItem key={item.href}>
                <SidebarMenuButton
                  asChild
                  isActive={pathname === item.href}
                  tooltip={{ children: item.label, className:"bg-card text-card-foreground border-border shadow-md" }}
                >
                  <Link href={item.href}>
                    <item.icon />
                    <span>{item.label}</span>
                  </Link>
                </SidebarMenuButton>
              </SidebarMenuItem>
            ))}
          </SidebarMenu>
        </SidebarGroup>

        <Separator className="my-4" />

        <SidebarGroup>
          <SidebarGroupLabel className="group-data-[collapsible=icon]:hidden">INTEGRATIONS</SidebarGroupLabel>
          <SidebarMenu>
            {integrationNavItems.map((item) => (
              <SidebarMenuItem key={item.href}>
                <SidebarMenuButton
                  asChild
                  isActive={pathname.startsWith(item.href)}
                  tooltip={{ children: item.label, className:"bg-card text-card-foreground border-border shadow-md" }}
                >
                  <Link href={item.href}>
                    <item.icon />
                    <span>{item.label}</span>
                  </Link>
                </SidebarMenuButton>
              </SidebarMenuItem>
            ))}
          </SidebarMenu>
        </SidebarGroup>
      </SidebarContent>

      <Separator />
      <SidebarFooter className="p-4 space-y-2 group-data-[collapsible=icon]:hidden">
          <div className="text-sm">
            <p className="font-semibold">Need Help?</p>
            <p className="text-xs text-muted-foreground">Check our documentation or contact support.</p>
          </div>
          <Button className="w-full">
            <LifeBuoy className="mr-2 h-4 w-4" /> Get Support
          </Button>
      </SidebarFooter>
    </Sidebar>
  );
};

export default AppSidebar;
