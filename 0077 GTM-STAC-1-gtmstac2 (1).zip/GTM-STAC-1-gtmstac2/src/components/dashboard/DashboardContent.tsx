// src/components/dashboard/DashboardContent.tsx
'use client';

import React, { useState, type FormEvent, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { BarChart, Users, Briefcase, MessageSquare, Building, Loader2 } from "lucide-react";
import { useRouter } from "next/navigation"; // Changed from react-router-dom
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useAuth } from '@/context/AuthContext';
import AiSalesIntelligenceSection from './AiSalesIntelligenceSection';
// Types are now mainly for the AI search, not directly used for display here
import type { SalesforceRecord, ProspectSummary, NextSteps } from '@/types'; 
// AI Flows will be called by the /search page
// import { generateProspectSummary } from '@/ai/flows/generate-prospect-summary';
// import { recommendNextSteps } from '@/ai/flows/recommend-next-steps';
// import { fetchSalesforceRecordByName } from '@/lib/salesforce';
import TodaysTasksCard from '@/components/layout/TodayTasksPanel'; 
// import PipelineHealthSection from './PipelineHealthSection'; // Still commented out

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { AlertCircle } from 'lucide-react';
import { db } from '@/lib/firebase';
import { doc, getDoc, updateDoc, setDoc } from 'firebase/firestore';

export default function DashboardContent() {
  const { user } = useAuth();
  const router = useRouter(); // Using Next.js router
  
  // AI Sales Intelligence Search State (only for term input on dashboard)
  const [aiSearchTerm, setAiSearchTerm] = useState('');
  // Removed states for results, loading, error as they are handled by /search page
  // const [isLoadingAiSearch, setIsLoadingAiSearch] = useState(false);
  // const [aiSearchError, setAiSearchError] = useState<string | null>(null);
  // const [aiSearchPerformed, setAiSearchPerformed] = useState(false);
  const [activeSource, setActiveSource] = useState<string>('All Sources');

  // const [prospectSummaryResult, setProspectSummaryResult] = useState<ProspectSummary | null>(null);
  // const [salesforceRecordResult, setSalesforceRecordResult] = useState<SalesforceRecord | null>(null);
  // const [nextStepsResult, setNextStepsResult] = useState<NextSteps | null>(null);

  // Company Name Modal State
  const [showCompanyModal, setShowCompanyModal] = useState(false);
  const [userCompanyNameInput, setUserCompanyNameInput] = useState('');
  const [isSavingCompany, setIsSavingCompany] = useState(false);
  const [modalError, setModalError] = useState<string | null>(null);
  const [checkedForCompany, setCheckedForCompany] = useState(false);

  useEffect(() => {
    const fetchUserDataAndCheckCompany = async () => {
      if (user && user.uid && !checkedForCompany) {
        try {
          const userDocRef = doc(db, "users", user.uid);
          const userDocSnap = await getDoc(userDocRef);

          if (userDocSnap.exists()) {
            const userData = userDocSnap.data();
            if (!userData.companyName || userData.companyName.trim() === "") {
              console.log("User companyName is missing, prompting for input.");
              setShowCompanyModal(true);
            }
          } else {
            console.log("User document not found in Firestore. Creating one and prompting for company name.");
            if (user.email && user.displayName) {
                 await setDoc(userDocRef, {
                    uid: user.uid,
                    email: user.email,
                    displayName: user.displayName,
                    companyName: "", 
                    createdAt: new Date().toISOString(),
                }, { merge: true });
                setShowCompanyModal(true);
            } else {
                console.warn("User email or displayName missing, cannot create user document for company prompt yet.");
            }
          }
        } catch (error) {
          console.error("Error fetching user data for company check:", error);
        } finally {
          setCheckedForCompany(true); 
        }
      } else if (user && !user.uid && !checkedForCompany) {
        console.warn("User object exists but UID is missing. Cannot check for company name.");
        setCheckedForCompany(true);
      }
    };

    fetchUserDataAndCheckCompany();
  }, [user, checkedForCompany]);
  
  const handleAiSearchSubmit = (searchTermToSearch?: string) => {
    const currentSearchTerm = searchTermToSearch || aiSearchTerm;
    if (!currentSearchTerm.trim()) {
      // Maybe show a small inline error or just do nothing
      console.log("Search term is empty");
      return;
    }
    // Navigate to the search page with the query
    router.push(`/search?q=${encodeURIComponent(currentSearchTerm)}`);
  };
  
  const handleSaveCompanyName = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setModalError(null);
    if (!userCompanyNameInput.trim()) {
      setModalError("Company name cannot be empty.");
      return;
    }
    if (!user || !user.uid) {
      setModalError("User not authenticated or user ID is missing.");
      console.error("Save company name: User not authenticated or UID missing.", user);
      return;
    }

    setIsSavingCompany(true);
    try {
      const userDocRef = doc(db, "users", user.uid);
      await updateDoc(userDocRef, {
        companyName: userCompanyNameInput.trim(),
      });
      setShowCompanyModal(false);
      setUserCompanyNameInput(''); 
    } catch (error: any) {
      console.error("Error saving company name:", error);
      setModalError(error.message || "Failed to save company name.");
    } finally {
      setIsSavingCompany(false);
    }
  };

  const userName = user?.displayName?.split(' ')[0] || "Sales Pro";

  return (
    <>
      <div className="p-6">
        {/* Welcome Section */}
        <section className="mb-8">
          <h1 className="text-2xl md:text-3xl font-bold text-primary mb-2">
            Welcome back, {userName}!
          </h1>
          <p className="text-muted-foreground">
            Here's what's happening with your sales pipeline today.
          </p>
        </section>

        {/* Main Content Area */}
        <div className="flex flex-col lg:flex-row gap-6">
          {/* Left/Main Column */}
          <div className="flex-1 space-y-8 lg:space-y-12">
            {/* AI Sales Intelligence Section - Now primarily for input */}
            <section>
              <AiSalesIntelligenceSection
                searchTerm={aiSearchTerm}
                onSearchTermChange={setAiSearchTerm}
                onSubmitSearch={() => handleAiSearchSubmit(aiSearchTerm)} 
                // isLoading, error, results props removed as they are handled by /search page
                // prospectSummary={null}
                // salesforceRecord={null}
                // nextSteps={null}
                // searchPerformed={false}
                activeSource={activeSource}
                onSourceChange={setActiveSource}
                onClearSearch={() => setAiSearchTerm('')}
              />
            </section>

            {/* Key Performance Metrics Placeholder */}
            <section className="mt-12">
              <h2 className="text-xl md:text-2xl font-semibold text-primary mb-4">Your Performance Snapshot</h2>
              <div className="grid md:grid-cols-2 lg:grid-cols-2 xl:grid-cols-4 gap-6">
                <Card className="shadow-sm">
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Active Leads</CardTitle>
                    <Users className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">120</div>
                    <p className="text-xs text-muted-foreground">+5 from yesterday</p>
                  </CardContent>
                </Card>
                <Card className="shadow-sm">
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Opportunities Won</CardTitle>
                    <Briefcase className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">15</div>
                    <p className="text-xs text-muted-foreground">+10% this month</p>
                  </CardContent>
                </Card>
                <Card className="shadow-sm">
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Conversion Rate</CardTitle>
                    <BarChart className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">25%</div>
                    <p className="text-xs text-muted-foreground">Target: 30%</p>
                  </CardContent>
                </Card>
                <Card className="shadow-sm">
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Messages Sent</CardTitle>
                    <MessageSquare className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">85</div>
                    <p className="text-xs text-muted-foreground">Using AI templates</p>
                  </CardContent>
                </Card>
              </div>
            </section>
            
            {/* <section>
              <PipelineHealthSection />
            </section> */}

            <section>
              <h2 className="text-xl md:text-2xl font-semibold text-primary mb-4">Quick Actions</h2>
              <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-4">
                <Button
                  variant="outline"
                  size="lg"
                  className="justify-start text-left h-auto py-4 shadow-sm hover:shadow-md"
                  onClick={() => router.push("/prospects")}
                >
                  <Users className="mr-3 h-5 w-5" />
                  <div>
                    <p className="font-semibold">Manage Leads</p>
                    <p className="text-xs text-muted-foreground">View, add, or edit your prospects.</p>
                  </div>
                </Button>
                <Button
                  variant="outline"
                  size="lg"
                  className="justify-start text-left h-auto py-4 shadow-sm hover:shadow-md"
                  onClick={() => router.push("/")} 
                >
                  <MessageSquare className="mr-3 h-5 w-5" />
                  <div>
                    <p className="font-semibold">Generate Sales Message</p>
                    <p className="text-xs text-muted-foreground">Craft AI-powered outreach.</p>
                  </div>
                </Button>
                <Button
                  variant="outline"
                  size="lg"
                  className="justify-start text-left h-auto py-4 shadow-sm hover:shadow-md"
                  onClick={() => router.push("/")} 
                >
                  <Briefcase className="mr-3 h-5 w-5" />
                  <div>
                    <p className="font-semibold">View Sales Materials</p>
                    <p className="text-xs text-muted-foreground">Access your documents and presentations.</p>
                  </div>
                </Button>
              </div>
            </section>
          </div>

          {/* Right Column - Today's Tasks */}
           <div className="lg:w-1/3 lg:max-w-sm xl:max-w-md">
             <TodaysTasksCard />
          </div>
        </div>
      </div>

      <Dialog open={showCompanyModal} onOpenChange={(open) => {
        if (!open && !isSavingCompany) { 
          setShowCompanyModal(false);
        }
      }}>
        <DialogContent className="sm:max-w-[425px]" onInteractOutside={(e) => {
          if (isSavingCompany) e.preventDefault();
        }}>
          <DialogHeader>
            <DialogTitle>Complete Your Profile</DialogTitle>
            <DialogDescription>
              Please enter your company name to personalize your experience.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSaveCompanyName} className="space-y-4 py-4" name="companyNameFormModal">
            {modalError && (
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertTitle>Error</AlertTitle>
                <AlertDescription>{modalError}</AlertDescription>
              </Alert>
            )}
            <div className="space-y-1">
              <Label htmlFor="companyNameModalInput">Company Name</Label>
              <div className="relative">
                <Building className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  id="companyNameModalInput"
                  placeholder="Your Company Inc."
                  value={userCompanyNameInput}
                  onChange={(e) => setUserCompanyNameInput(e.target.value)}
                  required
                  className="pl-8"
                  disabled={isSavingCompany}
                />
              </div>
            </div>
            <DialogFooter>
              <Button type="submit" disabled={isSavingCompany || !userCompanyNameInput.trim()}>
                {isSavingCompany ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Saving...
                  </>
                ) : (
                  'Save Company Name'
                )}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </>
  );
}
