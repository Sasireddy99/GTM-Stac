import type { ActivityStatData } from '@/types';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

interface ActivityStatCardProps {
  stat: ActivityStatData;
}

const ActivityStatCard: React.FC<ActivityStatCardProps> = ({ stat }) => {
  const changeColor = stat.changeType === 'positive' ? 'text-green-600' :
                      stat.changeType === 'negative' ? 'text-red-600' :
                      'text-muted-foreground';

  return (
    <Card className="bg-card shadow-sm border border-border">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-xs font-medium uppercase text-muted-foreground tracking-wider">{stat.title}</CardTitle>
          <stat.icon className="h-4 w-4 text-muted-foreground" />
        </div>
      </CardHeader>
      <CardContent>
        <div className="text-3xl font-bold text-foreground">{stat.value}</div>
        <p className={`text-xs ${changeColor} mt-1`}>
          {stat.change}
        </p>
      </CardContent>
    </Card>
  );
};

export default ActivityStatCard;
