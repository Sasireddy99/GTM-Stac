// src/components/dashboard/AiSalesIntelligenceSection.tsx
'use client';

import type { FormEvent } from 'react';
import Link from 'next/link';
import { Info, Search, ShieldCheck, Loader2, XCircle, Sparkles } from 'lucide-react';
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

interface AiSalesIntelligenceSectionProps {
  searchTerm: string;
  onSearchTermChange: (term: string) => void;
  onSubmitSearch: () => void;
  activeSource: string;
  onSourceChange: (source: string) => void;
  onClearSearch: () => void;
}

const AiSalesIntelligenceSection: React.FC<AiSalesIntelligenceSectionProps> = ({
  searchTerm,
  onSearchTermChange,
  onSubmitSearch,
  activeSource,
  onSourceChange,
  onClearSearch,
}) => {
  const handleLocalFormSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    onSubmitSearch();
  };

  const sourceFilters = ['All Sources', 'Salesforce Only', 'LinkedIn', 'ZoomInfo', 'Web Search'];

  return (
    <div className="p-6 bg-card rounded-lg shadow-sm border border-border">
      <div className="flex items-center mb-1">
        <ShieldCheck className="h-7 w-7 text-primary mr-2" />
        <h1 className="text-2xl font-semibold text-foreground">AI Sales Intelligence</h1>
      </div>
      <p className="text-sm text-muted-foreground mb-4">
        Search for prospects or companies to get AI-powered insights and sales recommendations.
      </p>

      <form onSubmit={handleLocalFormSubmit} method="GET" className="relative mb-3 flex items-center" name="aiSalesIntelligenceSearchForm">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground z-10" />
        <Sparkles className="absolute left-10 top-1/2 -translate-y-1/2 h-5 w-5 text-primary z-10" /> 
        <Input
          type="text"
          name="q" 
          placeholder="Search for a prospect or company..."
          className="pl-16 pr-28 py-2.5 text-base w-full bg-background border-2 border-primary rounded-lg focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 focus-visible:ring-offset-background transition-all duration-300 ease-in-out shadow-sm"
          value={searchTerm}
          onChange={(e) => onSearchTermChange(e.target.value)}
          aria-label="Search prospects or companies"
        />
        {searchTerm && (
          <Button
            type="button"
            variant="ghost"
            size="icon"
            className="absolute right-20 top-1/2 -translate-y-1/2 h-8 w-8 text-muted-foreground hover:text-destructive"
            onClick={onClearSearch}
            aria-label="Clear search"
          >
            <XCircle className="h-5 w-5" />
          </Button>
        )}
        <Button
          type="submit"
          variant="ghost"
          size="sm"
          className="absolute right-2 top-1/2 -translate-y-1/2 h-8 px-3 text-primary hover:bg-primary/10"
          disabled={!searchTerm.trim()}
          aria-label="Submit search"
        >
          Search
        </Button>
      </form>
      
      <div className="flex items-center text-xs text-muted-foreground mb-1">
        <Info className="h-3.5 w-3.5 mr-1.5" />
        <span>Try searching for a prospect name, company, industry, or specific need</span>
      </div>
      <div className="text-xs text-muted-foreground mb-4 ml-5">
          Powered by <Link href="/" className="text-primary hover:underline">SalesAI Navigator</Link>
      </div>

      <div className="flex flex-wrap gap-2 mb-6">
        {sourceFilters.map((source) => (
          <Button
            key={source}
            variant={activeSource === source ? 'default' : 'outline'}
            size="sm"
            className={activeSource === source ? '' : 'bg-card hover:bg-secondary/50'}
            onClick={() => onSourceChange(source)}
          >
            {source}
          </Button>
        ))}
      </div>
    </div>
  );
};

export default AiSalesIntelligenceSection;
