'use client';

import { useState } from 'react';
import ActivityStatCard from './ActivityStatCard';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { RefreshCw, Users, CalendarDays, Briefcase, LineChart } from 'lucide-react';
import type { ActivityStatData } from '@/types';

const initialStats: ActivityStatData[] = [
  { id: 'leads', title: 'New Leads', value: '1', change: '+5%', changeType: 'positive', icon: Users },
  { id: 'meetings', title: 'Meetings Scheduled', value: '0', change: '0%', changeType: 'neutral', icon: CalendarDays },
  { id: 'ops', title: 'Open Opportunities', value: '1', change: '+10%', changeType: 'positive', icon: Briefcase },
  { id: 'pipeline', title: 'Pipeline Value', value: '$25,000', change: '0%', changeType: 'neutral', icon: LineChart },
];

const SalesActivitySection = () => {
  const [stats, setStats] = useState<ActivityStatData[]>(initialStats);
  const [timePeriod, setTimePeriod] = useState<string>("this_week");

  // Placeholder for data fetching logic based on timePeriod
  const handleRefresh = () => {
    console.log("Refreshing stats for", timePeriod);
    // Simulate data refresh
    const newStats = stats.map(stat => ({
        ...stat,
        value: (parseInt(stat.value.replace(/\$|,/g, '')) * (Math.random() * 0.2 + 0.9)).toFixed(0).toString(), // Randomize value slightly
    }));
    // Re-add $ for pipeline
    const pipelineStat = newStats.find(s => s.id === 'pipeline');
    if (pipelineStat) pipelineStat.value = `$${parseInt(pipelineStat.value).toLocaleString()}`;

    setStats(newStats);
  };

  return (
    <div className="mt-6">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-semibold text-foreground">Sales Activity Dashboard</h2>
        <div className="flex items-center space-x-2">
          <Select value={timePeriod} onValueChange={setTimePeriod}>
            <SelectTrigger className="w-[150px] h-9 text-xs bg-card">
              <SelectValue placeholder="Select period" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="this_week">This Week</SelectItem>
              <SelectItem value="last_week">Last Week</SelectItem>
              <SelectItem value="this_month">This Month</SelectItem>
              <SelectItem value="last_month">Last Month</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" size="icon" className="h-9 w-9 bg-card" onClick={handleRefresh}>
            <RefreshCw className="h-4 w-4" />
          </Button>
        </div>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map(stat => (
          <ActivityStatCard key={stat.id} stat={stat} />
        ))}
      </div>
    </div>
  );
};

export default SalesActivitySection;
