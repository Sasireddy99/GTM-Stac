import type { RecentProspectData } from '@/types';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';

interface RecentProspectItemProps {
  prospect: RecentProspectData;
}

const RecentProspectItem: React.FC<RecentProspectItemProps> = ({ prospect }) => {
  const fallbackInitial = prospect.contactName ? prospect.contactName.charAt(0).toUpperCase() : prospect.name.charAt(0).toUpperCase();
  return (
    <div className="flex items-center justify-between p-4 border-b border-border last:border-b-0 hover:bg-secondary/30 transition-colors duration-150">
      <div className="flex items-center space-x-3">
        <Avatar className="h-10 w-10">
          <AvatarImage src={prospect.avatarUrl} alt={prospect.name} data-ai-hint={prospect.dataAiHint || "logo company"} />
          <AvatarFallback>{fallbackInitial}</AvatarFallback>
        </Avatar>
        <div>
          <p className="text-sm font-medium text-foreground">{prospect.name}</p>
          <p className="text-xs text-muted-foreground">{prospect.contactName} &bull; {prospect.email}</p>
        </div>
      </div>
      <Button variant="outline" size="sm" className="text-xs bg-card hover:bg-secondary/50">
        {prospect.status}
      </Button>
    </div>
  );
};

export default RecentProspectItem;
