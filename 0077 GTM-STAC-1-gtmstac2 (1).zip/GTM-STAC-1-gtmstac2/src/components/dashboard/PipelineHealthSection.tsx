
'use client';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import React from 'react';

interface PipelineStageProps {
  amount: string;
  stage: string;
  bgColorClass?: string;
  textColorClass?: string;
}

const PipelineStage: React.FC<PipelineStageProps> = ({
  amount,
  stage,
  bgColorClass = 'bg-blue-100',
  textColorClass = 'text-blue-700',
}) => {
  return (
    <div className="flex flex-col items-center text-center">
      <div
        className={`w-16 h-16 md:w-20 md:h-20 rounded-full flex items-center justify-center ${bgColorClass} shadow`}
      >
        <span className={`text-lg md:text-xl font-bold ${textColorClass}`}>{amount}</span>
      </div>
      <p className="mt-2 text-xs md:text-sm text-muted-foreground">{stage}</p>
    </div>
  );
};

const PipelineHealthSection: React.FC = () => {
  const pipelineData = [
    { amount: '320k', stage: 'Discovery' },
    { amount: '250k', stage: 'Proposal' },
    { amount: '525k', stage: 'Negotiation' },
    { amount: '475k', stage: 'Closed Won' },
    { amount: '180k', stage: 'Closed Lost', textColorClass: 'text-red-600', bgColorClass: 'bg-red-100' },
  ];

  const goalProgressValue = 15; // Example: 15%

  return (
    <Card className="shadow-lg border border-border">
      <CardContent className="p-6">
        <div className="grid md:grid-cols-2 gap-8">
          {/* Pipeline Health Section */}
          <div>
            <h3 className="text-xl font-semibold text-foreground mb-4">Pipeline Health</h3>
            <div className="flex justify-around items-start space-x-2 md:space-x-3">
              {pipelineData.map((item) => (
                <PipelineStage
                  key={item.stage}
                  amount={item.amount}
                  stage={item.stage}
                  bgColorClass={item.bgColorClass}
                  textColorClass={item.textColorClass}
                />
              ))}
            </div>
          </div>

          {/* Goal Progress Section */}
          <div>
            <h3 className="text-xl font-semibold text-foreground mb-4">Goal Progress</h3>
            <div className="space-y-3">
              <p className="text-sm text-muted-foreground">
                Q2 Revenue Goal: <span className="font-medium text-foreground">$2,000,000</span>
              </p>
              <Progress value={goalProgressValue} className="w-full h-3" />
              <p className="text-xs text-muted-foreground text-right">{goalProgressValue}% of goal achieved</p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default PipelineHealthSection;
