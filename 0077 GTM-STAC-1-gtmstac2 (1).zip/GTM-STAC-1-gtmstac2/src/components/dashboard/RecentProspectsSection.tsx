'use client';

import { useState } from 'react';
import Link from 'next/link';
import RecentProspectItem from './RecentProspectItem';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ArrowRight } from 'lucide-react';
import type { RecentProspectData } from '@/types';

const initialProspects: RecentProspectData[] = [
  { id: '1', name: 'Glean', contactName: 'Sasi Kumar Reddy Chanda', email: 'unknown@example.com', status: 'Open', avatarUrl: 'https://placehold.co/40x40.png?text=G', dataAiHint:'company logo' },
  { id: '2', name: 'Innovatech Solutions', contactName: 'Alice Wonderland', email: 'alice@innovatech.com', status: 'Qualified', avatarUrl: 'https://placehold.co/40x40.png?text=I', dataAiHint:'technology company' },
  { id: '3', name: 'GreenLeaf Organics', contactName: 'Bob The Builder', email: 'bob@greenleaf.com', status: 'Contacted', avatarUrl: 'https://placehold.co/40x40.png?text=G', dataAiHint:'nature retail' },
];

const RecentProspectsSection = () => {
  const [prospects, setProspects] = useState<RecentProspectData[]>(initialProspects);

  return (
    <Card className="mt-6 bg-card shadow-sm border border-border">
      <CardHeader>
        <div className="flex justify-between items-center">
          <CardTitle className="text-xl font-semibold text-foreground">Recent Prospects</CardTitle>
          <Link href="/prospects" className="text-sm text-primary hover:underline flex items-center">
            View All <ArrowRight className="h-4 w-4 ml-1" />
          </Link>
        </div>
      </CardHeader>
      <CardContent className="p-0"> {/* Remove padding as items will handle it */}
        {prospects.length > 0 ? (
          prospects.map(prospect => (
            <RecentProspectItem key={prospect.id} prospect={prospect} />
          ))
        ) : (
          <p className="text-sm text-muted-foreground text-center p-4">No recent prospects.</p>
        )}
      </CardContent>
    </Card>
  );
};

export default RecentProspectsSection;
