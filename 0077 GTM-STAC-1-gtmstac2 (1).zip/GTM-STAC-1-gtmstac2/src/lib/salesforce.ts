
import type { SalesforceRecord } from '@/types';
import { db } from './firebase';
import { collection, getDocs, query, where, limit, doc } from 'firebase/firestore';

// This constant might be dead code now if fetchAllSalesforceRecords is unused.
// However, fetchSalesforceRecordByName will use a path based on this structure.
const SALESFORCE_DATA_SUBCOLLECTION = 'salesforceData';
const ACCOUNTS_COLLECTION = 'accounts'; // For storing account/prospect type records

// This mock data is used by syncSalesforceDataAction
export const mockSalesforceData: SalesforceRecord[] = [
  {
    id: 'sf_mock_001',
    name: 'Innovatech Solutions (Mock)',
    contactPerson: 'Alice Wonderland',
    email: 'alice@innovatechmock.com',
    status: 'Qualified',
    lastContacted: '2024-05-01T10:00:00Z',
    industry: 'Technology',
    annualRevenue: 5000000,
    employeeCount: 150,
    source: 'Website',
    website: 'innovatechmock.com',
    address: {
      street: '123 Tech Drive',
      city: 'Techville',
      state: 'CA',
      postalCode: '90210',
      country: 'USA',
    },
  },
  {
    id: 'sf_mock_002',
    name: 'GreenLeaf Organics (Mock)',
    contactPerson: 'Bob The Builder',
    email: 'bob@greenleafmock.com',
    status: 'Lead',
    lastContacted: '2024-04-15T14:30:00Z',
    industry: 'Retail',
    annualRevenue: 1200000,
    employeeCount: 45,
    source: 'Referral',
    website: 'greenleafmock.com',
    address: {
      street: '456 Organic Ave',
      city: 'Farmburg',
      state: 'TX',
      postalCode: '73301',
      country: 'USA',
    },
  },
    {
    id: 'sf_mock_003',
    name: 'Quantum Dynamics (Mock)',
    contactPerson: 'Charlie Brown',
    email: 'charlie@quantummock.com',
    status: 'Customer',
    lastContacted: '2024-05-20T09:00:00Z',
    industry: 'Consulting',
    annualRevenue: 2500000,
    employeeCount: 75,
    source: 'Cold Call',
    website: 'quantummock.com',
  },
  {
    id: 'sf_mock_004',
    name: 'Pioneer Exports (Mock)',
    contactPerson: 'Diana Prince',
    email: 'diana@pioneermock.com',
    status: 'Contacted',
    lastContacted: '2024-05-10T11:00:00Z',
    industry: 'Logistics',
    annualRevenue: 10000000,
    employeeCount: 300,
    source: 'Trade Show',
    website: 'pioneermock.com',
  },
];

// Updated to fetch from a user-specific path
export async function fetchSalesforceRecordByName(name: string, userId: string): Promise<SalesforceRecord | null> {
  if (!userId) {
    console.error('[fetchSalesforceRecordByName] No userId provided. Cannot fetch record.');
    return null;
  }
  try {
    console.log(`[fetchSalesforceRecordByName] Searching for record with name "${name}" for user "${userId}" in path: users/${userId}/${SALESFORCE_DATA_SUBCOLLECTION}/${ACCOUNTS_COLLECTION}`);
    
    const recordsCollectionRef = collection(db, 'users', userId, SALESFORCE_DATA_SUBCOLLECTION, ACCOUNTS_COLLECTION);
    const q = query(recordsCollectionRef, where("name", "==", name), limit(1));
    const querySnapshot = await getDocs(q);

    if (!querySnapshot.empty) {
      const docData = querySnapshot.docs[0].data() as SalesforceRecord;
      console.log(`[fetchSalesforceRecordByName] Found record for user "${userId}":`, docData);
      return { ...docData, id: querySnapshot.docs[0].id };
    } else { // Corrected path reference in log message
      console.log(`[fetchSalesforceRecordByName] No record found with name "${name}" for user "${userId}" in path ${userAccountsPath}.`);
      return null;
    }
  } catch (error) {
    console.error(`[fetchSalesforceRecordByName] Error fetching Salesforce record by name "${name}" for user "${userId}":`, error);
    return null;
  }
}

// This function might be unused as pages fetch directly. Kept for now, but note it queries a general collection.
// If needed for user-specific data, it would also need a userId parameter.
export async function fetchAllSalesforceRecords(): Promise<SalesforceRecord[]> {
  const generalRecordsCollection = 'salesforce_records'; // This was the old general collection
  try {
    console.warn(`[fetchAllSalesforceRecords] Attempting to fetch all records from general collection '${generalRecordsCollection}'. This function may be deprecated or need user-specific context.`);
    const recordsCollectionRef = collection(db, generalRecordsCollection);
    const querySnapshot = await getDocs(recordsCollectionRef);

    if (!querySnapshot.empty) {
      const records = querySnapshot.docs.map(doc => ({ ...doc.data() as SalesforceRecord, id: doc.id }));
      console.log(`[fetchAllSalesforceRecords] Found ${records.length} records in general collection '${generalRecordsCollection}'.`);
      return records;
    } else {
      console.log(`[fetchAllSalesforceRecords] General collection '${generalRecordsCollection}' is empty.`);
      return []; 
    }
  } catch (error) {
    console.error(`[fetchAllSalesforceRecords] Error fetching all Salesforce records from general collection '${generalRecordsCollection}':`, error);
    return [];
  }
}
