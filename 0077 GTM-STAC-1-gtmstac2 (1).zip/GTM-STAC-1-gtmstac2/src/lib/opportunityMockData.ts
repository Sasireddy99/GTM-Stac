
import type { OpportunityData } from '@/types';
import { db } from './firebase';
import { collection, getDocs } from 'firebase/firestore';

const OPPORTUNITIES_COLLECTION = 'opportunities';

export const mockOpportunityData: OpportunityData[] = [
  {
    id: 'opp_mock_001',
    name: 'Innovatech Expansion Deal (Mock)',
    accountName: 'Innovatech Solutions (Mock)', // This should match a name in mockSalesforceData
    stage: 'Proposal/Price Quote',
    amount: 75000,
    closeDate: '2024-07-30T00:00:00Z',
    owner: 'Sales Rep A',
    probability: 0.6,
  },
  {
    id: 'opp_mock_002',
    name: 'GreenLeaf Partnership (Mock)',
    accountName: 'GreenLeaf Organics (Mock)', // This should match a name in mockSalesforceData
    stage: 'Needs Analysis',
    amount: 50000,
    closeDate: '2024-08-15T00:00:00Z',
    owner: 'Sales Rep B',
    probability: 0.3,
  },
  {
    id: 'opp_mock_003',
    name: 'Quantum Consulting Retainer (Mock)',
    accountName: 'Quantum Dynamics (Mock)',
    stage: 'Closed Won',
    amount: 120000,
    closeDate: '2024-06-10T00:00:00Z',
    owner: 'Sales Rep A',
    probability: 1.0,
  },
  {
    id: 'opp_mock_004',
    name: 'Pioneer Logistics Upgrade (Mock)',
    accountName: 'Pioneer Exports (Mock)',
    stage: 'Negotiation/Review',
    amount: 250000,
    closeDate: '2024-09-01T00:00:00Z',
    owner: 'Sales Rep C',
    probability: 0.75,
  },
];


export async function fetchAllOpportunities(): Promise<OpportunityData[]> {
  try {
    console.log(`[${OPPORTUNITIES_COLLECTION}] Attempting to fetch all opportunities from Firestore.`);
    const opportunitiesCollectionRef = collection(db, OPPORTUNITIES_COLLECTION);
    const querySnapshot = await getDocs(opportunitiesCollectionRef);

    if (!querySnapshot.empty) {
      const opportunities = querySnapshot.docs.map(doc => ({ ...doc.data() as OpportunityData, id: doc.id }));
      console.log(`[${OPPORTUNITIES_COLLECTION}] Found ${opportunities.length} opportunities in Firestore.`);
      return opportunities;
    } else {
      console.log(`[${OPPORTUNITIES_COLLECTION}] Firestore collection is empty. No opportunities to fetch.`);
      return []; // Return empty array if no opportunities are found, sync action will populate
    }
  } catch (error) {
    console.error(`[${OPPORTUNITIES_COLLECTION}] Error fetching all opportunities from Firestore:`, error);
    return []; // Return empty array on error
  }
}
